package com.tecnicsecure.service;

import com.tecnicsecure.dto.auth.LogActividadResponse;
import com.tecnicsecure.dto.auth.UsuarioAdminRequest;
import com.tecnicsecure.dto.auth.UsuarioResponse;
import com.tecnicsecure.dto.comun.PageResponse;
import org.springframework.data.domain.Pageable;

public interface UsuarioService {

    PageResponse<UsuarioResponse> listar(String texto, String rol, Pageable pageable);

    UsuarioResponse obtener(Integer idUsuario);

    UsuarioResponse crear(UsuarioAdminRequest request);

    UsuarioResponse actualizar(Integer idUsuario, UsuarioAdminRequest request);

    void cambiarEstado(Integer idUsuario, boolean activo);

    PageResponse<LogActividadResponse> auditoria(Pageable pageable);
}
