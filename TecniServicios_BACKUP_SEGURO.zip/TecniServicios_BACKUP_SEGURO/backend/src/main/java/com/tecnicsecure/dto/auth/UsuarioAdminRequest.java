package com.tecnicsecure.dto.auth;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

/** Datos para crear o actualizar un usuario desde el panel administrador. */
@Schema(description = "Datos de gestion de usuario por el administrador")
public record UsuarioAdminRequest(
        @NotBlank(message = "El nombre es obligatorio") @Size(max = 120) String nombre,
        @NotBlank(message = "El correo es obligatorio") @Email(message = "Correo invalido") @Size(max = 150) String correo,
        @Size(max = 30) String documento,
        @Size(max = 30) String telefono,
        @NotBlank(message = "El rol es obligatorio") String rol,
        @Size(min = 6, max = 100, message = "La contraseña debe tener entre 6 y 100 caracteres") String password,
        Boolean activo,
        Boolean bloqueado
) {
}
