package com.tecnicsecure.config;

import com.tecnicsecure.entity.Rol;
import com.tecnicsecure.entity.Usuario;
import com.tecnicsecure.repository.RolRepository;
import com.tecnicsecure.repository.UsuarioRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

/**
 * Garantiza que exista la cuenta administrador al arrancar.
 * La contrasena se puede cambiar con ADMIN_PASSWORD en las variables de entorno.
 */
@Configuration
public class DatosInicialesConfig {

    private static final Logger log = LoggerFactory.getLogger(DatosInicialesConfig.class);

    @Bean
    public ApplicationRunner crearAdministrador(UsuarioRepository usuarioRepository,
                                                RolRepository rolRepository,
                                                PasswordEncoder passwordEncoder,
                                                TecniSecureProperties propiedades) {
        return args -> {
            String correo = propiedades.admin().correo();

            if (usuarioRepository.findByCorreoIgnoreCase(correo).isPresent()) {
                log.info("Usuario administrador ya existe: {}", correo);
                return;
            }

            Rol rolAdmin = rolRepository.findByNombre(Rol.ADMINISTRADOR).orElseGet(() -> {
                Rol nuevo = new Rol();
                nuevo.setNombre(Rol.ADMINISTRADOR);
                return rolRepository.save(nuevo);
            });

            Usuario admin = new Usuario();
            admin.setRol(rolAdmin);
            admin.setNombre("Administrador Principal");
            admin.setCorreo(correo.toLowerCase());
            admin.setPasswordHash(passwordEncoder.encode(propiedades.admin().password()));
            admin.setActivo(true);
            admin.setBloqueado(false);
            admin.setIntentosFallidos(0);
            usuarioRepository.save(admin);

            log.info("Usuario administrador creado: {}", correo);
        };
    }
}
