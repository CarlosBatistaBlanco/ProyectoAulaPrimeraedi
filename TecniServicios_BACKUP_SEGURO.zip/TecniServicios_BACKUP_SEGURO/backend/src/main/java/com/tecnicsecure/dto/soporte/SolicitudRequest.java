package com.tecnicsecure.dto.soporte;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;

import java.time.LocalDate;
import java.time.LocalTime;

@Schema(description = "Solicitud de cotizacion o cita tecnica")
public record SolicitudRequest(
        @NotNull(message = "El servicio es obligatorio") Integer idServicio,
        @NotBlank(message = "El nombre es obligatorio") @Size(max = 120) String nombre,
        @NotBlank(message = "El correo es obligatorio")
        @Email(message = "El correo no es valido") String correo,
        @NotBlank(message = "El telefono es obligatorio") @Size(max = 30) String telefono,
        @Size(max = 255) String direccion,
        @NotBlank(message = "El tipo es obligatorio (cotizacion o cita)") String tipo,
        LocalDate fechaPreferida,
        LocalTime horaPreferida,
        @Size(max = 2000) String descripcion
) {
}
