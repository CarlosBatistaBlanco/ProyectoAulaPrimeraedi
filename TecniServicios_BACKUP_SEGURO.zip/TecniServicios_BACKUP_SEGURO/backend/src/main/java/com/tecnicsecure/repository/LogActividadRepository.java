package com.tecnicsecure.repository;

import com.tecnicsecure.entity.LogActividad;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LogActividadRepository extends JpaRepository<LogActividad, Integer> {

    Page<LogActividad> findAllByOrderByCreadoEnDesc(Pageable pageable);
}
