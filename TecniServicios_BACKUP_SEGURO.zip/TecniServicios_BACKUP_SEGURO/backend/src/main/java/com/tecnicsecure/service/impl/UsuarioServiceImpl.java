package com.tecnicsecure.service.impl;

import com.tecnicsecure.dto.auth.LogActividadResponse;
import com.tecnicsecure.dto.auth.UsuarioAdminRequest;
import com.tecnicsecure.dto.auth.UsuarioResponse;
import com.tecnicsecure.dto.comun.PageResponse;
import com.tecnicsecure.entity.Cliente;
import com.tecnicsecure.entity.LogActividad;
import com.tecnicsecure.entity.Rol;
import com.tecnicsecure.entity.Usuario;
import com.tecnicsecure.exception.ApiException;
import com.tecnicsecure.repository.ClienteRepository;
import com.tecnicsecure.repository.LogActividadRepository;
import com.tecnicsecure.repository.RolRepository;
import com.tecnicsecure.repository.UsuarioRepository;
import com.tecnicsecure.service.UsuarioService;
import com.tecnicsecure.util.UsuarioActual;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class UsuarioServiceImpl implements UsuarioService {

    private final UsuarioRepository usuarioRepository;
    private final RolRepository rolRepository;
    private final ClienteRepository clienteRepository;
    private final LogActividadRepository logRepository;
    private final PasswordEncoder passwordEncoder;
    private final UsuarioActual usuarioActual;

    public UsuarioServiceImpl(UsuarioRepository usuarioRepository,
                              RolRepository rolRepository,
                              ClienteRepository clienteRepository,
                              LogActividadRepository logRepository,
                              PasswordEncoder passwordEncoder,
                              UsuarioActual usuarioActual) {
        this.usuarioRepository = usuarioRepository;
        this.rolRepository = rolRepository;
        this.clienteRepository = clienteRepository;
        this.logRepository = logRepository;
        this.passwordEncoder = passwordEncoder;
        this.usuarioActual = usuarioActual;
    }

    @Override
    @Transactional(readOnly = true)
    public PageResponse<UsuarioResponse> listar(String texto, String rol, Pageable pageable) {
        String filtroTexto = StringUtils.hasText(texto) ? texto.trim() : null;
        String filtroRol = StringUtils.hasText(rol) ? rol.trim().toLowerCase() : null;
        return PageResponse.de(usuarioRepository.buscar(filtroTexto, filtroRol, pageable), UsuarioResponse::de);
    }

    @Override
    @Transactional(readOnly = true)
    public UsuarioResponse obtener(Integer idUsuario) {
        return UsuarioResponse.de(buscarUsuario(idUsuario));
    }

    @Override
    @Transactional
    public UsuarioResponse crear(UsuarioAdminRequest request) {
        String correo = request.correo().trim().toLowerCase();
        if (usuarioRepository.existsByCorreoIgnoreCase(correo)) {
            throw ApiException.conflict("Ya existe un usuario con ese correo");
        }
        String documento = StringUtils.hasText(request.documento()) ? request.documento().trim() : null;
        if (documento != null && usuarioRepository.existsByDocumento(documento)) {
            throw ApiException.conflict("Ya existe un usuario con ese documento");
        }
        if (!StringUtils.hasText(request.password())) {
            throw ApiException.badRequest("La contraseña es obligatoria al crear un usuario");
        }

        Rol rol = buscarRol(request.rol());

        Usuario usuario = new Usuario();
        usuario.setNombre(request.nombre().trim());
        usuario.setCorreo(correo);
        usuario.setDocumento(documento);
        usuario.setTelefono(StringUtils.hasText(request.telefono()) ? request.telefono().trim() : null);
        usuario.setRol(rol);
        usuario.setPasswordHash(passwordEncoder.encode(request.password()));
        usuario.setActivo(request.activo() == null || request.activo());
        usuario.setBloqueado(Boolean.TRUE.equals(request.bloqueado()));
        usuarioRepository.save(usuario);

        sincronizarFichaCliente(usuario);
        registrarLog("crear_usuario", "Usuario #" + usuario.getIdUsuario() + " (" + correo + ")");
        return UsuarioResponse.de(usuario);
    }

    @Override
    @Transactional
    public UsuarioResponse actualizar(Integer idUsuario, UsuarioAdminRequest request) {
        Usuario usuario = buscarUsuario(idUsuario);
        String correo = request.correo().trim().toLowerCase();

        if (!correo.equalsIgnoreCase(usuario.getCorreo()) && usuarioRepository.existsByCorreoIgnoreCase(correo)) {
            throw ApiException.conflict("Ya existe otro usuario con ese correo");
        }
        String documento = StringUtils.hasText(request.documento()) ? request.documento().trim() : null;
        if (documento != null && !documento.equalsIgnoreCase(usuario.getDocumento())
                && usuarioRepository.existsByDocumento(documento)) {
            throw ApiException.conflict("Ya existe otro usuario con ese documento");
        }

        Rol rol = buscarRol(request.rol());
        Usuario actor = usuarioActual.requerir();
        if (actor.getIdUsuario().equals(idUsuario) && Boolean.FALSE.equals(request.activo())) {
            throw ApiException.badRequest("No puedes desactivar tu propia cuenta de administrador");
        }

        usuario.setNombre(request.nombre().trim());
        usuario.setCorreo(correo);
        usuario.setDocumento(documento);
        usuario.setTelefono(StringUtils.hasText(request.telefono()) ? request.telefono().trim() : null);
        usuario.setRol(rol);
        if (StringUtils.hasText(request.password())) {
            usuario.setPasswordHash(passwordEncoder.encode(request.password()));
        }
        if (request.activo() != null) {
            usuario.setActivo(request.activo());
        }
        if (request.bloqueado() != null) {
            usuario.setBloqueado(request.bloqueado());
            if (!request.bloqueado()) {
                usuario.setIntentosFallidos(0);
                usuario.setBloqueadoHasta(null);
            }
        }

        usuarioRepository.save(usuario);
        sincronizarFichaCliente(usuario);
        registrarLog("actualizar_usuario", "Usuario #" + idUsuario + " (" + correo + ")");
        return UsuarioResponse.de(usuario);
    }

    @Override
    @Transactional
    public void cambiarEstado(Integer idUsuario, boolean activo) {
        Usuario actor = usuarioActual.requerir();
        if (actor.getIdUsuario().equals(idUsuario) && !activo) {
            throw ApiException.badRequest("No puedes desactivar tu propia cuenta");
        }
        Usuario usuario = buscarUsuario(idUsuario);
        usuario.setActivo(activo);
        usuarioRepository.save(usuario);
        registrarLog(activo ? "activar_usuario" : "desactivar_usuario", "Usuario #" + idUsuario);
    }

    @Override
    @Transactional(readOnly = true)
    public PageResponse<LogActividadResponse> auditoria(Pageable pageable) {
        Page<LogActividad> logs = logRepository.findAllByOrderByCreadoEnDesc(pageable);
        Set<Integer> ids = logs.getContent().stream()
                .map(LogActividad::getIdUsuario)
                .filter(Objects::nonNull)
                .collect(Collectors.toSet());
        Map<Integer, String> nombres = usuarioRepository.findAllById(ids).stream()
                .collect(Collectors.toMap(Usuario::getIdUsuario, Usuario::getNombre));

        return PageResponse.de(logs, l -> LogActividadResponse.de(
                l, l.getIdUsuario() != null ? nombres.getOrDefault(l.getIdUsuario(), "Usuario #" + l.getIdUsuario()) : "Sistema"));
    }

    private Usuario buscarUsuario(Integer idUsuario) {
        return usuarioRepository.findById(idUsuario)
                .orElseThrow(() -> ApiException.notFound("Usuario no encontrado"));
    }

    private Rol buscarRol(String nombreRol) {
        String nombre = nombreRol.trim().toLowerCase();
        return rolRepository.findByNombre(nombre)
                .orElseThrow(() -> ApiException.badRequest("Rol invalido: " + nombreRol));
    }

    private void sincronizarFichaCliente(Usuario usuario) {
        if (!usuario.esCliente()) {
            return;
        }
        Cliente cliente = clienteRepository.findByUsuarioIdUsuario(usuario.getIdUsuario())
                .orElseGet(Cliente::new);
        cliente.setUsuario(usuario);
        cliente.setNombre(usuario.getNombre());
        cliente.setCorreo(usuario.getCorreo());
        cliente.setTelefono(usuario.getTelefono());
        clienteRepository.save(cliente);
    }

    private void registrarLog(String accion, String detalle) {
        LogActividad log = new LogActividad();
        log.setIdUsuario(usuarioActual.idOpcional());
        log.setAccion(accion);
        log.setDetalle(detalle);
        logRepository.save(log);
    }
}
