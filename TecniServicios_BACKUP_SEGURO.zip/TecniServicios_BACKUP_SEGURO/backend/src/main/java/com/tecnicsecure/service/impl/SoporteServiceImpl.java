package com.tecnicsecure.service.impl;

import com.tecnicsecure.dto.comun.PageResponse;
import com.tecnicsecure.dto.soporte.*;
import com.tecnicsecure.entity.*;
import com.tecnicsecure.exception.ApiException;
import com.tecnicsecure.repository.*;
import com.tecnicsecure.service.SoporteService;
import com.tecnicsecure.util.UsuarioActual;
import org.springframework.data.domain.Pageable;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.Map;

@Service
public class SoporteServiceImpl implements SoporteService {

    private final ContactoRepository contactoRepository;
    private final SolicitudServicioRepository solicitudRepository;
    private final ServicioRepository servicioRepository;
    private final MensajeChatRepository chatRepository;
    private final NotificacionRepository notificacionRepository;
    private final ClienteRepository clienteRepository;
    private final UsuarioRepository usuarioRepository;
    private final UsuarioActual usuarioActual;
    private final SimpMessagingTemplate mensajeria;

    public SoporteServiceImpl(ContactoRepository contactoRepository,
                              SolicitudServicioRepository solicitudRepository,
                              ServicioRepository servicioRepository,
                              MensajeChatRepository chatRepository,
                              NotificacionRepository notificacionRepository,
                              ClienteRepository clienteRepository,
                              UsuarioRepository usuarioRepository,
                              UsuarioActual usuarioActual,
                              SimpMessagingTemplate mensajeria) {
        this.contactoRepository = contactoRepository;
        this.solicitudRepository = solicitudRepository;
        this.servicioRepository = servicioRepository;
        this.chatRepository = chatRepository;
        this.notificacionRepository = notificacionRepository;
        this.clienteRepository = clienteRepository;
        this.usuarioRepository = usuarioRepository;
        this.usuarioActual = usuarioActual;
        this.mensajeria = mensajeria;
    }

    @Override
    @Transactional
    public ContactoResponse registrarContacto(ContactoRequest request) {
        Contacto contacto = new Contacto();
        contacto.setNombre(request.nombre().trim());
        contacto.setCorreo(request.correo().trim().toLowerCase());
        contacto.setTelefono(request.telefono());
        contacto.setAsunto(request.asunto());
        contacto.setTipo(StringUtils.hasText(request.tipo()) ? request.tipo() : "mensaje");
        contacto.setMensaje(request.mensaje().trim());
        contacto.setIdUsuario(usuarioActual.idOpcional());
        contacto.setLeido(false);
        contactoRepository.save(contacto);

        notificarGestion("Nuevo mensaje de contacto",
                contacto.getNombre() + ": " + contacto.getAsunto(),
                "/panel/administrador/soporte");

        return ContactoResponse.de(contacto);
    }

    @Override
    @Transactional(readOnly = true)
    public PageResponse<ContactoResponse> listarContactos(Boolean soloNoLeidos, Pageable pageable) {
        return Boolean.TRUE.equals(soloNoLeidos)
                ? PageResponse.de(contactoRepository.findByLeidoFalseOrderByCreadoEnDesc(pageable), ContactoResponse::de)
                : PageResponse.de(contactoRepository.findAll(pageable), ContactoResponse::de);
    }

    @Override
    @Transactional
    public ContactoResponse responderContacto(Integer idContacto, String respuesta) {
        Contacto contacto = contactoRepository.findById(idContacto)
                .orElseThrow(() -> ApiException.notFound("Mensaje no encontrado"));
        contacto.setRespuesta(respuesta);
        contacto.setLeido(true);
        contactoRepository.save(contacto);
        return ContactoResponse.de(contacto);
    }

    @Override
    @Transactional
    public SolicitudResponse crearSolicitud(SolicitudRequest request) {
        Servicio servicio = servicioRepository.findById(request.idServicio())
                .orElseThrow(() -> ApiException.badRequest("El servicio indicado no existe"));

        String tipo = request.tipo() == null ? "" : request.tipo().trim().toLowerCase();
        if (!tipo.equals("cotizacion") && !tipo.equals("cita")) {
            throw ApiException.badRequest("El tipo debe ser 'cotizacion' o 'cita'");
        }
        if (tipo.equals("cita") && request.fechaPreferida() == null) {
            throw ApiException.badRequest("Para agendar una cita indica la fecha preferida");
        }

        SolicitudServicio solicitud = new SolicitudServicio();
        solicitud.setServicio(servicio);
        solicitud.setNombre(request.nombre().trim());
        solicitud.setCorreo(request.correo().trim().toLowerCase());
        solicitud.setTelefono(request.telefono().trim());
        solicitud.setDireccion(request.direccion());
        solicitud.setTipo(tipo);
        solicitud.setFechaPreferida(request.fechaPreferida());
        solicitud.setHoraPreferida(request.horaPreferida());
        solicitud.setDescripcion(request.descripcion());
        solicitud.setEstado("pendiente");
        solicitudRepository.save(solicitud);

        notificarGestion("Nueva solicitud de servicio",
                solicitud.getNombre() + " - " + servicio.getTitulo(),
                "/panel/administrador/soporte");

        return SolicitudResponse.de(solicitud);
    }

    @Override
    @Transactional(readOnly = true)
    public PageResponse<SolicitudResponse> listarSolicitudes(String estado, Pageable pageable) {
        return StringUtils.hasText(estado)
                ? PageResponse.de(solicitudRepository.findByEstadoOrderByCreadoEnDesc(estado, pageable), SolicitudResponse::de)
                : PageResponse.de(solicitudRepository.findAll(pageable), SolicitudResponse::de);
    }

    @Override
    @Transactional
    public SolicitudResponse gestionarSolicitud(Integer idSolicitud, SolicitudGestionRequest request) {
        SolicitudServicio solicitud = solicitudRepository.findById(idSolicitud)
                .orElseThrow(() -> ApiException.notFound("Solicitud no encontrada"));

        if (request.tecnicoAsignado() != null) {
            solicitud.setTecnicoAsignado(request.tecnicoAsignado());
        }
        if (request.observaciones() != null) {
            solicitud.setObservaciones(request.observaciones());
        }
        if (StringUtils.hasText(request.estado())) {
            solicitud.setEstado(request.estado());
        }
        solicitudRepository.save(solicitud);
        return SolicitudResponse.de(solicitud);
    }

    @Override
    @Transactional
    public List<MensajeChatResponse> conversacion(Integer idCliente) {
        marcarLeidosCliente(idCliente, "cliente");
        return chatRepository.findByIdClienteOrderByCreadoEnAsc(idCliente)
                .stream().map(MensajeChatResponse::de).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<Map<String, Object>> listarClientesChat() {
        return clienteRepository.findAll().stream()
                .map(c -> {
                    Map<String, Object> fila = new java.util.LinkedHashMap<>();
                    fila.put("idCliente", c.getIdCliente());
                    fila.put("nombre", c.getNombre() == null ? "" : c.getNombre());
                    fila.put("correo", c.getCorreo() == null ? "" : c.getCorreo());
                    return fila;
                })
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public Integer clienteIdDelUsuario(Integer idUsuario) {
        return clienteRepository.findByUsuarioIdUsuario(idUsuario)
                .map(Cliente::getIdCliente)
                .orElseThrow(() -> ApiException.notFound("No tienes un perfil de cliente asociado"));
    }

    @Override
    @Transactional
    public List<MensajeChatResponse> conversacionPropia() {
        Cliente cliente = clienteDelUsuarioActual();
        return conversacion(cliente.getIdCliente());
    }

    @Override
    @Transactional
    public MensajeChatResponse enviarMensajeCliente(Integer idCliente, String mensaje,
                                                    Integer idUsuario, boolean esCliente) {
        if (!StringUtils.hasText(mensaje)) {
            throw ApiException.badRequest("El mensaje no puede estar vacío");
        }
        clienteRepository.findById(idCliente)
                .orElseThrow(() -> ApiException.notFound("Cliente no encontrado"));

        MensajeChat chat = new MensajeChat();
        chat.setIdCliente(idCliente);
        chat.setRemitente(esCliente ? "cliente" : "asesor");
        chat.setIdUsuarioEnvia(idUsuario);
        chat.setMensaje(mensaje.trim());
        chat.setLeido(false);
        chatRepository.save(chat);

        MensajeChatResponse respuesta = MensajeChatResponse.de(chat);

        // Comunicacion en tiempo real para este hilo de conversacion.
        mensajeria.convertAndSend("/topic/chat/" + idCliente, respuesta);

        if (esCliente) {
            notificarGestion("Nuevo mensaje de chat",
                    "El cliente #" + idCliente + " escribió",
                    "/panel/administrador/chat");
        } else {
            clienteRepository.findById(idCliente).ifPresent(c -> {
                if (c.getUsuario() != null) {
                    notificar(c.getUsuario().getIdUsuario(), "Nueva respuesta del asesor",
                            chat.getMensaje(), "/panel/cliente/chat");
                }
            });
        }

        return respuesta;
    }

    @Override
    @Transactional(readOnly = true)
    public List<NotificacionResponse> misNotificaciones() {
        Usuario usuario = usuarioActual.requerir();
        return notificacionRepository.findTop30ByIdUsuarioOrderByCreadoEnDesc(usuario.getIdUsuario())
                .stream().map(NotificacionResponse::de).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public long contarNotificacionesSinLeer() {
        Usuario usuario = usuarioActual.requerir();
        return notificacionRepository.countByIdUsuarioAndLeidaFalse(usuario.getIdUsuario());
    }

    @Override
    @Transactional
    public void marcarNotificacionesLeidas() {
        Usuario usuario = usuarioActual.requerir();
        List<Notificacion> pendientes =
                notificacionRepository.findTop30ByIdUsuarioOrderByCreadoEnDesc(usuario.getIdUsuario());
        pendientes.stream().filter(n -> !Boolean.TRUE.equals(n.getLeida())).forEach(n -> n.setLeida(true));
        notificacionRepository.saveAll(pendientes);
    }

    @Override
    @Transactional
    public void notificar(Integer idUsuario, String titulo, String mensaje, String enlace) {
        if (idUsuario == null) {
            return;
        }
        Notificacion notificacion = new Notificacion();
        notificacion.setIdUsuario(idUsuario);
        notificacion.setTitulo(titulo);
        notificacion.setMensaje(mensaje);
        notificacion.setEnlace(enlace);
        notificacion.setLeida(false);
        notificacionRepository.save(notificacion);

        mensajeria.convertAndSend("/topic/notificaciones/" + idUsuario, NotificacionResponse.de(notificacion));
    }

    private void notificarGestion(String titulo, String mensaje, String enlace) {
        usuarioRepository.findByRolNombre(Rol.ADMINISTRADOR)
                .forEach(u -> notificar(u.getIdUsuario(), titulo, mensaje, enlace));
    }

    private Cliente clienteDelUsuarioActual() {
        Usuario usuario = usuarioActual.requerir();
        return clienteRepository.findByUsuarioIdUsuario(usuario.getIdUsuario())
                .orElseThrow(() -> ApiException.notFound("No tienes un perfil de cliente asociado"));
    }

    private void marcarLeidosCliente(Integer idCliente, String remitente) {
        var pendientes = chatRepository.findByIdClienteOrderByCreadoEnAsc(idCliente).stream()
                .filter(m -> remitente.equals(m.getRemitente()) && !Boolean.TRUE.equals(m.getLeido()))
                .toList();
        pendientes.forEach(m -> m.setLeido(true));
        chatRepository.saveAll(pendientes);
    }
}
