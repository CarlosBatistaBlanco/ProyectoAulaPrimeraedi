package com.tecnicsecure.dto.pedido;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

import java.util.List;

@Schema(description = "Checkout del carrito de compras")
public record PedidoRequest(
        @NotBlank(message = "El nombre es obligatorio") @Size(max = 120) String nombre,
        @NotBlank(message = "El correo es obligatorio")
        @Email(message = "El correo no es valido") String correo,
        @Size(max = 30) String telefono,
        @Size(max = 255) String direccion,
        @NotEmpty(message = "El carrito esta vacio")
        @Valid
        List<ItemCarrito> carrito
) {

    @Schema(description = "Linea del carrito")
    public record ItemCarrito(
            @NotNull(message = "El producto es obligatorio") Integer idProducto,
            @NotNull(message = "La cantidad es obligatoria")
            @Min(value = 1, message = "La cantidad minima es 1") Integer cantidad
    ) {
    }
}
