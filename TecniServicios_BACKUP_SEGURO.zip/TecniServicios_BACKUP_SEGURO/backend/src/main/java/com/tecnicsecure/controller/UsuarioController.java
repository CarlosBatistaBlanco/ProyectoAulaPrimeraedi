package com.tecnicsecure.controller;

import com.tecnicsecure.dto.auth.LogActividadResponse;
import com.tecnicsecure.dto.auth.UsuarioAdminRequest;
import com.tecnicsecure.dto.auth.UsuarioResponse;
import com.tecnicsecure.dto.comun.PageResponse;
import com.tecnicsecure.service.UsuarioService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@Tag(name = "7. Usuarios y Auditoria", description = "Gestion administrativa de usuarios y registro de actividad")
@RestController
@RequestMapping("/api")
@PreAuthorize("hasRole('ADMINISTRADOR')")
public class UsuarioController {

    private final UsuarioService usuarioService;

    public UsuarioController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    @Operation(summary = "Listar usuarios con filtros por texto y rol")
    @GetMapping("/usuarios")
    public PageResponse<UsuarioResponse> listar(@RequestParam(required = false) String texto,
                                                @RequestParam(required = false) String rol,
                                                @RequestParam(defaultValue = "0") int pagina,
                                                @RequestParam(defaultValue = "50") int tamanio) {
        return usuarioService.listar(texto, rol,
                PageRequest.of(Math.max(0, pagina), Math.min(100, Math.max(1, tamanio)),
                        Sort.by(Sort.Direction.ASC, "idUsuario")));
    }

    @Operation(summary = "Obtener un usuario por id")
    @GetMapping("/usuarios/{id}")
    public UsuarioResponse obtener(@PathVariable Integer id) {
        return usuarioService.obtener(id);
    }

    @Operation(summary = "Crear un usuario (administrador, empleado o cliente)")
    @PostMapping("/usuarios")
    public ResponseEntity<UsuarioResponse> crear(@Valid @RequestBody UsuarioAdminRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(usuarioService.crear(request));
    }

    @Operation(summary = "Actualizar datos, rol o estado de un usuario")
    @PutMapping("/usuarios/{id}")
    public UsuarioResponse actualizar(@PathVariable Integer id, @Valid @RequestBody UsuarioAdminRequest request) {
        return usuarioService.actualizar(id, request);
    }

    @Operation(summary = "Desactivar un usuario (baja logica)")
    @DeleteMapping("/usuarios/{id}")
    public ResponseEntity<Void> desactivar(@PathVariable Integer id) {
        usuarioService.cambiarEstado(id, false);
        return ResponseEntity.noContent().build();
    }

    @Operation(summary = "Consultar historial de auditoria del sistema")
    @GetMapping("/auditoria")
    public PageResponse<LogActividadResponse> auditoria(@RequestParam(defaultValue = "0") int pagina,
                                                        @RequestParam(defaultValue = "50") int tamanio) {
        return usuarioService.auditoria(
                PageRequest.of(Math.max(0, pagina), Math.min(100, Math.max(1, tamanio))));
    }
}
