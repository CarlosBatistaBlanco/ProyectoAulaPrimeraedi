package com.tecnicsecure.dto.auth;

import jakarta.validation.constraints.Size;

/** Datos que el usuario puede modificar de su propio perfil. */
public record PerfilRequest(
        @Size(max = 120) String nombre,
        @Size(max = 30) String telefono,
        @Size(max = 30) String documento,
        String avatar,
        String passwordActual,
        String passwordNueva
) {
}
