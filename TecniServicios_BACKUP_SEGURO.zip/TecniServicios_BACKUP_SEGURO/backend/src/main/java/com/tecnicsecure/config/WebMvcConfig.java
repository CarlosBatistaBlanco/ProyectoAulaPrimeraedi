package com.tecnicsecure.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.servlet.config.annotation.ContentNegotiationConfigurer;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.nio.charset.StandardCharsets;
import java.util.List;

/**
 * Configuración MVC (la "C" del patrón MVC):
 * — garantiza JSON y texto siempre en UTF-8 (ñ, tildes y símbolos);
 * — publica /uploads e /img desde el frontend;
 * — sirve index.html en la raíz, sustituyendo a Apache.
 */
@Configuration
public class WebMvcConfig implements WebMvcConfigurer {

    private final TecniSecureProperties propiedades;

    public WebMvcConfig(TecniSecureProperties propiedades) {
        this.propiedades = propiedades;
    }

    @Override
    public void configureContentNegotiation(ContentNegotiationConfigurer configurer) {
        configurer
                .favorParameter(false)
                .ignoreAcceptHeader(false)
                .defaultContentType(MediaType.APPLICATION_JSON);
    }

    @Override
    public void extendMessageConverters(List<HttpMessageConverter<?>> converters) {
        // Texto plano y CSV en UTF-8 (Excel y navegadores respetan los acentos)
        for (HttpMessageConverter<?> converter : converters) {
            if (converter instanceof StringHttpMessageConverter texto) {
                texto.setDefaultCharset(StandardCharsets.UTF_8);
            }
            if (converter instanceof MappingJackson2HttpMessageConverter json) {
                json.setSupportedMediaTypes(List.of(
                        MediaType.APPLICATION_JSON,
                        new MediaType("application", "json", StandardCharsets.UTF_8)));
            }
        }
    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // Rutas absolutas: funcionan sin importar el directorio de trabajo.
        String raizFrontend = rutaFrontend();

        registry.addResourceHandler("/uploads/**")
                .addResourceLocations(comoUrl(propiedades.uploads() != null && propiedades.uploads().dir() != null
                        ? propiedades.uploads().dir()
                        : "../frontend/uploads"));
        registry.addResourceHandler("/css/**").addResourceLocations(raizFrontend + "css/");
        registry.addResourceHandler("/js/**").addResourceLocations(raizFrontend + "js/");
        registry.addResourceHandler("/img/**").addResourceLocations(raizFrontend + "img/");
        registry.addResourceHandler("/video/**").addResourceLocations(raizFrontend + "video/");
        registry.addResourceHandler("/audio/**").addResourceLocations(raizFrontend + "audio/");
    }

    /** Ruta absoluta de la carpeta frontend (hermana de backend). */
    private String rutaFrontend() {
        String configurada = System.getProperty("frontend.dir");
        if (configurada != null && !configurada.isBlank()) {
            return comoUrl(configurada);
        }
        java.nio.file.Path candidata = java.nio.file.Path.of("..", "frontend").toAbsolutePath().normalize();
        return comoUrl(candidata.toString());
    }

    private String comoUrl(String ruta) {
        String normalizada = ruta.replace('\\', '/');
        if (!normalizada.endsWith("/")) {
            normalizada = normalizada + "/";
        }
        return normalizada.startsWith("file:") ? normalizada : "file:" + normalizada;
    }
}
