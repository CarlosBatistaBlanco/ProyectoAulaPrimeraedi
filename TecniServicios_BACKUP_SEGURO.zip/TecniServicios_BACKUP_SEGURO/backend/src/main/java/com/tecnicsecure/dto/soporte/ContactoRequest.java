package com.tecnicsecure.dto.soporte;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@Schema(description = "Mensaje del formulario de contacto")
public record ContactoRequest(
        @NotBlank(message = "El nombre es obligatorio") @Size(max = 120) String nombre,
        @NotBlank(message = "El correo es obligatorio")
        @Email(message = "El correo no es valido") String correo,
        @Size(max = 30) String telefono,
        @Size(max = 150) String asunto,
        @Pattern(regexp = "mensaje|reclamo|sugerencia", message = "Tipo de mensaje no valido")
        String tipo,
        @NotBlank(message = "El mensaje es obligatorio") @Size(max = 4000) String mensaje
) {
}
