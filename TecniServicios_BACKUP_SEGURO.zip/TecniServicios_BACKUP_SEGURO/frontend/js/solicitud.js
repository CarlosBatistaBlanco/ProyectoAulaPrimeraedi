/**
 * solicitud.js — Solicitud de cotización o cita técnica
 * -----------------------------------------------------------------
 * Solicitud de cotizaci?n o cita t?cnica:
 *   · carga el servicio desde GET /api/servicios (según ?id=)
 *   · permite elegir entre cotización y cita con fecha/hora
 *   · envía todo a POST /api/solicitudes
 */

const ICONOS_SERVICIO = {
  camera: 'fa-solid fa-video',
  monitor: 'fa-solid fa-display',
  bell: 'fa-solid fa-bell',
  lock: 'fa-solid fa-fingerprint',
  wrench: 'fa-solid fa-screwdriver-wrench',
  clipboard: 'fa-solid fa-clipboard-list'
};

async function cargarServicio() {
  const id = Number(new URLSearchParams(window.location.search).get('id') || 0);
  const titulo = document.getElementById('tituloServicio');
  const descripcion = document.getElementById('descripcionServicio');
  if (!titulo || !id) return null;

  try {
    const servicios = await Api.servicios();
    const servicio = servicios.find((s) => Number(s.idServicio) === id);
    if (!servicio) {
      window.location.href = '../index.html#servicios';
      return null;
    }
    titulo.textContent = `Solicitar: ${servicio.titulo}`;
    descripcion.textContent = servicio.descripcion;
    document.title = `Solicitar: ${servicio.titulo} | TECNISECURE`;
    return servicio;
  } catch {
    descripcion.textContent = 'No se pudo cargar la información del servicio.';
    return null;
  }
}

function inicializarSolicitud() {
  const form = document.getElementById('formSolicitud');
  if (!form) return;

  const alumno = null; // sin datos precargados: el visitante puede ser anónimo
  const usuario = Api.getUsuario();
  if (usuario) {
    if (form.nombre && !form.nombre.value) form.nombre.value = usuario.nombre || '';
    if (form.correo && !form.correo.value) form.correo.value = usuario.correo || '';
    if (form.telefono && !form.telefono.value) form.telefono.value = usuario.telefono || '';
  }

  // Fecha mínima: hoy
  const fecha = document.getElementById('fecha_preferida');
  if (fecha) fecha.min = new Date().toISOString().split('T')[0];

  cargarServicio();

  const idServicio = Number(new URLSearchParams(window.location.search).get('id') || 0);

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const alertaPrevia = form.querySelector('.auth-alerta');
    if (alertaPrevia) alertaPrevia.remove();

    const boton = form.querySelector('button[type="submit"]');
    const textoOriginal = boton.innerHTML;
    boton.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Enviando...';
    boton.disabled = true;

    const datos = {
      idServicio,
      nombre: form.nombre.value.trim(),
      correo: form.correo.value.trim(),
      telefono: form.telefono.value.trim(),
      direccion: form.direccion ? form.direccion.value.trim() : '',
      tipo: form.tipo.value,
      descripcion: form.descripcion.value.trim()
    };

    if (datos.tipo === 'cita') {
      datos.fechaPreferida = form.fecha_preferida.value || null;
      datos.horaPreferida = form.hora_preferida.value || null;
      if (!datos.fechaPreferida) {
        mostrarMensaje(form, 'Para agendar una cita indica la fecha preferida.', 'error');
        boton.innerHTML = textoOriginal;
        boton.disabled = false;
        return;
      }
    }

    try {
      await Api.solicitarServicio(datos);
      form.reset();
      mostrarMensaje(form,
        '¡Solicitud recibida! Un asesor se pondrá en contacto contigo muy pronto.', 'ok');
    } catch (error) {
      mostrarMensaje(form, error.message, 'error');
      boton.innerHTML = textoOriginal;
      boton.disabled = false;
    }
  });
}

function mostrarMensaje(form, texto, tipo) {
  const aviso = document.createElement('div');
  aviso.className = `auth-alerta auth-alerta--${tipo === 'ok' ? 'ok' : 'error'}`;
  aviso.style.marginBottom = '20px';
  aviso.textContent = texto;
  form.parentElement.insertBefore(aviso, form);
}

document.addEventListener('DOMContentLoaded', inicializarSolicitud);
