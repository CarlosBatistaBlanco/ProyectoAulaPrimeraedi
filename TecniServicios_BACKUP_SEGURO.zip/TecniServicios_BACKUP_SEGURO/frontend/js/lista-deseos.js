/**
 * lista_deseos.js — Lista de compras del visitante
 * -----------------------------------------------------------------
 * La lista se guarda en localStorage (funciona sin iniciar sesión) y,
 * si el usuario es cliente, se sincroniza con favoritos en la API.
 */

const DESEOS_KEY = 'tecniservicios_deseos';

function leerDeseos() {
  const datos = localStorage.getItem(DESEOS_KEY);
  return datos ? JSON.parse(datos) : [];
}

function guardarDeseos(lista) {
  localStorage.setItem(DESEOS_KEY, JSON.stringify(lista));
  actualizarContadorDeseos();
  document.dispatchEvent(new CustomEvent('deseos:actualizada', { detail: lista }));
}

function actualizarContadorDeseos() {
  const contador = document.getElementById('deseosContador');
  if (contador) contador.textContent = leerDeseos().length;
}

function quitarDeDeseos(idProducto) {
  guardarDeseos(leerDeseos().filter((p) => Number(p.id_producto) !== Number(idProducto)));
  renderizarListaDeseos();
}

function renderizarListaDeseos() {
  const contenedor = document.getElementById('listaDeseosGrid');
  if (!contenedor) return;

  const lista = leerDeseos();
  if (!lista.length) {
    contenedor.innerHTML = `<div class="catalogo__vacio">
      <i class="fa-solid fa-heart-crack"></i>
      <h3>Tu lista de compras está vacía</h3>
      <p>Marca el corazón de los productos que te interesen y los encontrarás aquí.</p>
      <a href="productos.html" class="btn btn--primario">Ver catálogo</a>
    </div>`;
    return;
  }

  contenedor.innerHTML = lista.map((p) => `
    <article class="tarjeta-producto">
      <div class="tarjeta-producto__imagen">
        <button type="button" class="btn-favorito activo" data-id="${p.id_producto}"
                title="Quitar de mi lista"><i class="fa-solid fa-heart"></i></button>
        <img src="${escaparHtml(p.imagen)}" alt="${escaparHtml(p.nombre)}"
             onerror="this.src='../img/productos/sin-imagen.jpg'">
      </div>
      <div class="tarjeta-producto__info">
        ${p.marca ? `<span class="tarjeta-producto__marca">${escaparHtml(p.marca)}</span>` : ''}
        <h3>${escaparHtml(p.nombre)}</h3>
        <div class="tarjeta-producto__footer">
          <span class="precio">${formatearPesos(p.precio)}</span>
          <button class="btn-agregar" data-id="${p.id_producto}"
                  data-nombre="${escaparHtml(p.nombre)}" data-precio="${p.precio}"
                  data-imagen="${escaparHtml(p.imagen)}">
            <i class="fa-solid fa-cart-plus"></i> Agregar
          </button>
        </div>
      </div>
    </article>`).join('');

  contenedor.querySelectorAll('.btn-favorito').forEach((boton) => {
    boton.addEventListener('click', () => quitarDeDeseos(boton.dataset.id));
  });

  contenedor.querySelectorAll('.btn-agregar').forEach((boton) => {
    boton.addEventListener('click', () => {
      const producto = {
        id_producto: Number(boton.dataset.id),
        nombre: boton.dataset.nombre,
        precio: Number(boton.dataset.precio),
        imagen: boton.dataset.imagen
      };
      if (typeof agregarAlCarrito === 'function') agregarAlCarrito(producto);
    });
  });
}

/** Marca los corazones de los productos ya guardados en la lista. */
function marcarFavoritosGuardados() {
  const ids = leerDeseos().map((p) => Number(p.id_producto));
  document.querySelectorAll('.btn-favorito[data-id]').forEach((boton) => {
    if (ids.includes(Number(boton.dataset.id))) boton.classList.add('activo');
  });
}

/** Activa los botones de las tarjetas generadas dinámicamente. */
function inicializarBotonesTarjetas() {
  document.querySelectorAll('.btn-agregar').forEach((boton) => {
    if (boton.dataset.activo) return;
    boton.dataset.activo = 'true';
    boton.addEventListener('click', () => {
      if (typeof agregarAlCarrito !== 'function') return;
      agregarAlCarrito({
        id_producto: Number(boton.dataset.id),
        nombre: boton.dataset.nombre,
        precio: Number(boton.dataset.precio),
        imagen: boton.dataset.imagen
      });
    });
  });

  document.querySelectorAll('.btn-favorito').forEach((boton) => {
    if (boton.dataset.activo) return;
    boton.dataset.activo = 'true';
    boton.addEventListener('click', () => {
      const lista = leerDeseos();
      const id = Number(boton.dataset.id);
      const existe = lista.find((p) => Number(p.id_producto) === id);
      const nueva = existe
        ? lista.filter((p) => Number(p.id_producto) !== id)
        : [...lista, {
            id_producto: id,
            nombre: boton.dataset.nombre,
            precio: Number(boton.dataset.precio),
            imagen: boton.dataset.imagen,
            marca: boton.dataset.marca || ''
          }];

      guardarDeseos(nueva);
      boton.classList.toggle('activo', !existe);

      if (typeof Api !== 'undefined' && Api.estaAutenticado()
          && Api.getUsuario()?.rol === 'cliente') {
        Api.alternarFavorito(id).catch(() => {});
      }
    });
  });

  marcarFavoritosGuardados();
}

document.addEventListener('DOMContentLoaded', () => {
  actualizarContadorDeseos();
  renderizarListaDeseos();
});
