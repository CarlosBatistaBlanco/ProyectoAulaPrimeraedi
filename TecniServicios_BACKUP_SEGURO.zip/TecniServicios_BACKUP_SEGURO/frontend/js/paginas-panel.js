/**
 * paginas-panel.js — Datos de cada módulo del panel
 * -----------------------------------------------------------------
 * Carga la información desde la API REST según la página abierta:
 * dashboard, usuarios, productos, pedidos, inventario, reportes,
 * soporte, chats, favoritos, perfil y mis pedidos.
 */

const NOMBRES_ESTADO = {
  pendiente: 'Pendiente',
  confirmado: 'Confirmado',
  en_preparacion: 'En preparación',
  empacado: 'Empacado',
  enviado: 'Enviado',
  entregado: 'Entregado',
  cancelado: 'Cancelado'
};

const SIGUIENTE_ESTADO = {
  pendiente: 'confirmado',
  confirmado: 'en_preparacion',
  en_preparacion: 'empacado',
  empacado: 'enviado',
  enviado: 'entregado'
};

function estadoLegible(estado) {
  return NOMBRES_ESTADO[estado] || estado || '—';
}

function fechaCorta(valor) {
  return valor ? new Date(valor).toLocaleDateString('es-CO') : '—';
}

function tablaVacia(tbody, columnas, mensaje = 'No hay información para mostrar.') {
  tbody.innerHTML = `<tr><td colspan="${columnas}" style="text-align:center; color:var(--texto-tenue);">${mensaje}</td></tr>`;
}

function textoImporte(valor) {
  return `$${Number(valor || 0).toLocaleString('es-CO', { maximumFractionDigits: 0 })}`;
}

function asignar(id, valor) {
  const elemento = document.getElementById(id);
  if (elemento) elemento.textContent = valor;
}

/* --------------------------- Dashboard admin --------------------------- */

async function cargarDashboardAdmin() {
  try {
    const [resumen, pedidos] = await Promise.all([
      Api.resumenReporte(),
      Api.pedidos({ tamanio: 8 })
    ]);

    asignar('statUsuarios', resumen.usuariosActivos ?? 0);
    asignar('statClientes', resumen.usuariosActivos ?? 0);
    asignar('statProductos', resumen.productosActivos ?? 0);
    asignar('statPedidos', resumen.cantidadPedidos ?? 0);
    asignar('statVentas', textoImporte(resumen.ingresosHistoricos));

    const aviso = document.getElementById('avisoStockBajo');
    if (aviso && Number(resumen.productosStockBajo) > 0) {
      aviso.innerHTML = `<i class="fa-solid fa-triangle-exclamation"></i> ${resumen.productosStockBajo} producto(s) con stock bajo.`;
    }

    const tablaResumen = document.getElementById('tablaResumenMes');
    if (tablaResumen) {
      tablaResumen.innerHTML = [
        ['Pedidos del período', resumen.cantidadPedidos ?? 0],
        ['Ingresos del período', textoImporte(resumen.ingresosPeriodo)],
        ['Ingresos históricos', textoImporte(resumen.ingresosHistoricos)],
        ['Productos con stock bajo', resumen.productosStockBajo ?? 0],
        ['Solicitudes pendientes', resumen.solicitudesPendientes ?? 0],
        ['Mensajes sin leer', resumen.mensajesContactoSinLeer ?? 0]
      ].map(([k, v]) => `<tr><td>${k}</td><td><strong>${v}</strong></td></tr>`).join('');
    }

    pintarPedidos('tablaUltimosPedidos', pedidos.contenido, false);
  } catch (error) {
    console.warn('Dashboard administrador:', error.message);
  }
}

/* -------------------------- Dashboard cliente -------------------------- */

async function cargarDashboardCliente() {
  const [pedidos, favoritos] = await Promise.all([
    Api.misPedidos().catch(() => ({ contenido: [] })),
    Api.favoritos().catch(() => [])
  ]);

  asignar('statMisPedidos', pedidos.contenido ? pedidos.contenido.length : 0);
  asignar('statMisFavoritos', favoritos.length || 0);

  const tbody = document.getElementById('tablaMisPedidos');
  if (!tbody) return;

  if (!pedidos.contenido || !pedidos.contenido.length) {
    tablaVacia(tbody, 4, 'Aún no tienes pedidos.');
    return;
  }

  tbody.innerHTML = pedidos.contenido.slice(0, 5).map((p) => `
    <tr>
      <td>#${p.idPedido}</td>
      <td>${fechaCorta(p.creadoEn)}</td>
      <td>${textoImporte(p.total)}</td>
      <td><span class="badge-rol">${estadoLegible(p.estado)}</span></td>
    </tr>`).join('');
}

/* ------------------------- Dashboard empleado -------------------------- */

async function cargarDashboardEmpleado() {
  try {
    const [resumen, pedidos, stock] = await Promise.all([
      Api.resumenReporte(),
      Api.pedidos({ tamanio: 8 }).catch(() => ({ contenido: [] })),
      Api.stockBajo().catch(() => [])
    ]);

    asignar('statPedidosPendientes', resumen.cantidadPedidos ?? 0);
    asignar('statStockBajo', stock.length || resumen.productosStockBajo || 0);
    asignar('statVentasMes', textoImporte(resumen.ingresosPeriodo));
    pintarPedidos('tablaUltimosPedidos', pedidos.contenido, false);
  } catch (error) {
    console.warn('Dashboard empleado:', error.message);
  }
}

/* ------------------------------ Modales -------------------------------- */

function abrirModal(id) {
  document.getElementById(id)?.classList.add('activo');
}

function cerrarModal(id) {
  document.getElementById(id)?.classList.remove('activo');
}
window.abrirModal = abrirModal;
window.cerrarModal = cerrarModal;

/* ------------------------------ Usuarios ------------------------------- */

let rolFijoUsuarios = '';

function inicializarUsuarios() {
  const box = document.querySelector('[data-rol-fijo]');
  rolFijoUsuarios = box ? (box.dataset.rolFijo || '') : '';

  const buscar = document.getElementById('buscarUsuario');
  const filtroRol = document.getElementById('filtroRolUsuario');
  const btnNuevo = document.getElementById('btnNuevoUsuario');
  const form = document.getElementById('formUsuario');

  let timer;
  if (buscar) {
    buscar.addEventListener('input', () => {
      clearTimeout(timer);
      timer = setTimeout(cargarUsuarios, 250);
    });
  }
  if (filtroRol) filtroRol.addEventListener('change', cargarUsuarios);

  if (btnNuevo && form) {
    btnNuevo.addEventListener('click', () => {
      form.reset();
      form.idUsuario.value = '';
      form.activo.checked = true;
      form.bloqueado.checked = false;
      form.rol.value = rolFijoUsuarios || 'cliente';
      form.password.required = true;
      const lblPass = document.getElementById('etiquetaPasswordUsuario');
      if (lblPass) lblPass.textContent = 'Contraseña *';
      const resp = document.getElementById('respuestaUsuario');
      if (resp) { resp.textContent = ''; resp.className = 'form-respuesta campo--full'; }
      const titulo = document.getElementById('tituloModalUsuario');
      if (titulo) titulo.innerHTML = `<i class="fa-solid fa-user-plus"></i> Nuevo ${rolFijoUsuarios || 'usuario'}`;
      abrirModal('modalUsuario');
    });
  }

  if (form) {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const resp = document.getElementById('respuestaUsuario');
      resp.textContent = '';
      resp.className = 'form-respuesta campo--full';

      const id = form.idUsuario.value;
      const datos = {
        nombre: form.nombre.value.trim(),
        correo: form.correo.value.trim(),
        documento: form.documento.value.trim() || null,
        telefono: form.telefono.value.trim() || null,
        rol: form.rol.value,
        password: form.password.value ? form.password.value : null,
        activo: form.activo.checked,
        bloqueado: form.bloqueado.checked
      };

      try {
        if (id) {
          await Api.actualizarUsuario(id, datos);
        } else {
          await Api.crearUsuario(datos);
        }
        cerrarModal('modalUsuario');
        await cargarUsuarios();
      } catch (error) {
        resp.textContent = error.message;
        resp.className = 'form-respuesta error campo--full';
      }
    });
  }

  cargarUsuarios();
}

async function cargarUsuarios() {
  const tbody = document.getElementById('tablaUsuarios');
  if (!tbody) return;

  const texto = (document.getElementById('buscarUsuario')?.value || '').trim();
  const rol = rolFijoUsuarios || (document.getElementById('filtroRolUsuario')?.value || '');

  try {
    const datos = await Api.usuarios({ texto, rol, tamanio: 100 });
    const lista = datos.contenido || [];
    if (!lista.length) {
      tablaVacia(tbody, 7, 'No se encontraron usuarios.');
      return;
    }

    tbody.innerHTML = lista.map((u) => {
      const estadoBadge = u.bloqueado
        ? '<span class="badge-estado badge-estado--bloqueado">Bloqueado</span>'
        : (u.activo
          ? '<span class="badge-estado badge-estado--activo">Activo</span>'
          : '<span class="badge-estado badge-estado--inactivo">Inactivo</span>');

      return `
        <tr>
          <td>${escaparHtml(u.nombre)}</td>
          <td>${escaparHtml(u.correo)}</td>
          <td>${escaparHtml(u.documento || '—')}</td>
          <td><span class="badge-rol">${escaparHtml(u.rol)}</span></td>
          <td>${estadoBadge}</td>
          <td>${fechaCorta(u.creadoEn)}</td>
          <td>
            <div class="panel-acciones">
              <button type="button" class="panel-accion-btn" title="Editar" onclick="editarUsuario(${u.idUsuario})">
                <i class="fa-solid fa-pen"></i>
              </button>
              ${u.activo ? `
              <button type="button" class="panel-accion-btn panel-accion-btn--peligro" title="Desactivar"
                      onclick="desactivarUsuario(${u.idUsuario}, '${escaparHtml(u.nombre)}')">
                <i class="fa-solid fa-user-slash"></i>
              </button>` : ''}
            </div>
          </td>
        </tr>`;
    }).join('');
  } catch (error) {
    tablaVacia(tbody, 7, error.message);
  }
}

async function editarUsuario(id) {
  const form = document.getElementById('formUsuario');
  if (!form) return;
  try {
    const u = await Api.usuario(id);
    form.idUsuario.value = u.idUsuario;
    form.nombre.value = u.nombre || '';
    form.correo.value = u.correo || '';
    form.documento.value = u.documento || '';
    form.telefono.value = u.telefono || '';
    form.rol.value = u.rol || 'cliente';
    form.password.value = '';
    form.password.required = false;
    form.activo.checked = Boolean(u.activo);
    form.bloqueado.checked = Boolean(u.bloqueado);
    const lblPass = document.getElementById('etiquetaPasswordUsuario');
    if (lblPass) lblPass.textContent = 'Nueva contraseña (opcional)';
    const resp = document.getElementById('respuestaUsuario');
    if (resp) { resp.textContent = ''; resp.className = 'form-respuesta campo--full'; }
    const titulo = document.getElementById('tituloModalUsuario');
    if (titulo) titulo.innerHTML = `<i class="fa-solid fa-user-pen"></i> Editar usuario #${u.idUsuario}`;
    abrirModal('modalUsuario');
  } catch (error) {
    alert(error.message);
  }
}

async function desactivarUsuario(id, nombre) {
  if (!confirm(`¿Desactivar la cuenta de "${nombre}"?`)) return;
  try {
    await Api.eliminarUsuario(id);
    await cargarUsuarios();
  } catch (error) {
    alert(error.message);
  }
}

window.editarUsuario = editarUsuario;
window.desactivarUsuario = desactivarUsuario;

/* ----------------------------- Productos ------------------------------- */

async function inicializarProductos() {
  const buscar = document.getElementById('buscarProducto');
  const filtroCat = document.getElementById('filtroCategoriaProducto');
  const btnNuevo = document.getElementById('btnNuevoProducto');
  const form = document.getElementById('formProducto');

  try {
    const [cats, marcas] = await Promise.all([Api.categorias(), Api.marcas()]);
    const optsCat = cats.map((c) => `<option value="${c.idCategoria}">${escaparHtml(c.nombre)}</option>`).join('');
    if (filtroCat) filtroCat.innerHTML = `<option value="">Todas las categorías</option>${optsCat}`;
    const selCat = document.getElementById('prodCategoria');
    if (selCat) selCat.innerHTML = `<option value="">Sin categoría</option>${optsCat}`;

    const selMarca = document.getElementById('prodMarca');
    if (selMarca) {
      selMarca.innerHTML = `<option value="">Sin marca</option>` +
        marcas.map((m) => `<option value="${m.idMarca || ''}">${escaparHtml(m.nombre)}</option>`).join('');
    }
  } catch (error) {
    console.warn('Catálogos:', error.message);
  }

  let timer;
  if (buscar) {
    buscar.addEventListener('input', () => {
      clearTimeout(timer);
      timer = setTimeout(cargarProductos, 250);
    });
  }
  if (filtroCat) filtroCat.addEventListener('change', cargarProductos);

  if (btnNuevo && form) {
    btnNuevo.addEventListener('click', () => {
      form.reset();
      form.idProducto.value = '';
      form.activo.checked = true;
      form.destacado.checked = false;
      form.descuentoPct.value = 0;
      form.stockMinimo.value = 5;
      form.garantiaMeses.value = 12;
      const resp = document.getElementById('respuestaProducto');
      if (resp) { resp.textContent = ''; resp.className = 'form-respuesta campo--full'; }
      const titulo = document.getElementById('tituloModalProducto');
      if (titulo) titulo.innerHTML = '<i class="fa-solid fa-plus"></i> Nuevo producto';
      abrirModal('modalProducto');
    });
  }

  if (form) {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const resp = document.getElementById('respuestaProducto');
      resp.textContent = '';
      resp.className = 'form-respuesta campo--full';

      const id = form.idProducto.value;
      const datos = {
        nombre: form.nombre.value.trim(),
        sku: form.sku.value.trim() || null,
        codigoBarras: null,
        descripcion: form.descripcion.value.trim() || null,
        precio: Number(form.precio.value || 0),
        descuentoPct: Number(form.descuentoPct.value || 0),
        impuestoPct: 19,
        garantiaMeses: Number(form.garantiaMeses.value || 12),
        stock: Number(form.stock.value || 0),
        stockMinimo: Number(form.stockMinimo.value || 5),
        stockMaximo: 100,
        imagen: form.imagen.value.trim() || null,
        destacado: form.destacado.checked,
        activo: form.activo.checked,
        idCategoria: form.idCategoria.value ? Number(form.idCategoria.value) : null,
        idMarca: form.idMarca.value ? Number(form.idMarca.value) : null
      };

      try {
        if (id) {
          await Api.actualizarProducto(id, datos);
        } else {
          await Api.crearProducto(datos);
        }
        cerrarModal('modalProducto');
        await cargarProductos();
      } catch (error) {
        resp.textContent = error.message;
        resp.className = 'form-respuesta error campo--full';
      }
    });
  }

  await cargarProductos();
}

async function cargarProductos() {
  const tbody = document.getElementById('tablaProductos');
  if (!tbody) return;

  const texto = (document.getElementById('buscarProducto')?.value || '').trim();
  const idCategoria = document.getElementById('filtroCategoriaProducto')?.value || '';

  try {
    const datos = await Api.productos({ texto, idCategoria, tamanio: 100 });
    if (!datos.contenido.length) {
      tablaVacia(tbody, 8, 'No se encontraron productos.');
      return;
    }

    tbody.innerHTML = datos.contenido.map((p) => `
      <tr>
        <td>${escaparHtml(p.sku || '—')}</td>
        <td>${escaparHtml(p.nombre)}</td>
        <td>${escaparHtml(p.categoria || '—')}</td>
        <td>${escaparHtml(p.marca || '—')}</td>
        <td>${p.stock}</td>
        <td>${textoImporte(p.precioFinal)}</td>
        <td>${p.stockBajo
          ? '<span class="badge-estado badge-estado--bloqueado">Stock bajo</span>'
          : '<span class="badge-estado badge-estado--activo">Disponible</span>'}</td>
        <td>
          <div class="panel-acciones">
            <button type="button" class="panel-accion-btn" title="Editar" onclick="editarProducto(${p.idProducto})">
              <i class="fa-solid fa-pen"></i>
            </button>
            <button type="button" class="panel-accion-btn panel-accion-btn--peligro" title="Desactivar"
                    onclick="eliminarProducto(${p.idProducto}, '${escaparHtml(p.nombre)}')">
              <i class="fa-solid fa-trash"></i>
            </button>
          </div>
        </td>
      </tr>`).join('');
  } catch (error) {
    tablaVacia(tbody, 8, error.message);
  }
}

async function editarProducto(id) {
  const form = document.getElementById('formProducto');
  if (!form) return;
  try {
    const p = await Api.producto(id);
    form.idProducto.value = p.idProducto;
    form.nombre.value = p.nombre || '';
    form.sku.value = p.sku || '';
    form.idCategoria.value = p.idCategoria || '';
    form.idMarca.value = p.idMarca || '';
    form.precio.value = p.precio ?? 0;
    form.descuentoPct.value = p.descuentoPct ?? 0;
    form.stock.value = p.stock ?? 0;
    form.stockMinimo.value = p.stockMinimo ?? 5;
    form.garantiaMeses.value = p.garantiaMeses ?? 12;
    form.imagen.value = p.imagen || '';
    form.descripcion.value = p.descripcion || '';
    form.destacado.checked = Boolean(p.destacado);
    form.activo.checked = Boolean(p.activo);
    const resp = document.getElementById('respuestaProducto');
    if (resp) { resp.textContent = ''; resp.className = 'form-respuesta campo--full'; }
    const titulo = document.getElementById('tituloModalProducto');
    if (titulo) titulo.innerHTML = `<i class="fa-solid fa-pen"></i> Editar producto #${p.idProducto}`;
    abrirModal('modalProducto');
  } catch (error) {
    alert(error.message);
  }
}

async function eliminarProducto(id, nombre) {
  if (!confirm(`¿Desactivar el producto "${nombre}" del catálogo?`)) return;
  try {
    await Api.eliminarProducto(id);
    await cargarProductos();
  } catch (error) {
    alert(error.message);
  }
}

window.editarProducto = editarProducto;
window.eliminarProducto = eliminarProducto;

/* ------------------------------ Pedidos -------------------------------- */

function pintarPedidos(idTabla, pedidos, conAcciones) {
  const tbody = document.getElementById(idTabla);
  if (!tbody) return;

  if (!pedidos || !pedidos.length) {
    tablaVacia(tbody, conAcciones ? 6 : 5, 'Todavía no hay pedidos registrados.');
    return;
  }

  tbody.innerHTML = pedidos.map((p) => {
    const siguiente = SIGUIENTE_ESTADO[p.estado];
    const accion = conAcciones
      ? (siguiente
        ? `<button class="btn btn--primario" style="padding:6px 12px; font-size:.8rem;"
                   onclick="avanzarPedido(${p.idPedido}, '${siguiente}')">
             ${estadoLegible(siguiente)}</button>`
        : '<span style="color:var(--texto-tenue);">—</span>')
      : '';

    return `
      <tr>
        <td>#${p.idPedido}</td>
        <td>${escaparHtml(p.clienteNombre || '—')}</td>
        <td>${textoImporte(p.total)}</td>
        <td><span class="badge-rol">${estadoLegible(p.estado)}</span></td>
        <td>${fechaCorta(p.creadoEn)}</td>
        ${conAcciones ? `<td>${accion}</td>` : ''}
      </tr>`;
  }).join('');
}

async function cargarPedidos() {
  const tbody = document.getElementById('tablaPedidos');
  if (!tbody) return;
  try {
    const datos = await Api.pedidos({ tamanio: 50 });
    pintarPedidos('tablaPedidos', datos.contenido, true);
  } catch (error) {
    tablaVacia(tbody, 6, error.message);
  }
}

async function avanzarPedido(idPedido, nuevoEstado) {
  try {
    await Api.cambiarEstadoPedido(idPedido, nuevoEstado);
    await cargarPedidos();
  } catch (error) {
    alert(error.message);
  }
}

/* ----------------------------- Inventario ------------------------------ */

async function cargarInventario() {
  const tbodyBajo = document.getElementById('tablaStockBajo');
  const tbodyTodo = document.getElementById('tablaInventario');

  try {
    const bajos = await Api.stockBajo();
    if (tbodyBajo) {
      tbodyBajo.innerHTML = bajos.length
        ? bajos.map((p) => `<tr>
            <td>${escaparHtml(p.nombre)}</td>
            <td>${escaparHtml(p.sku || '—')}</td>
            <td><strong style="color:#ffb199">${p.stock}</strong></td>
            <td>${p.stockMinimo}</td>
            <td>${p.stockMaximo}</td>
          </tr>`).join('')
        : '<tr><td colspan="5" style="text-align:center; color:var(--texto-tenue);">Todo el inventario está por encima del mínimo.</td></tr>';
    }

    if (tbodyTodo) {
      const todos = await Api.inventario();
      tbodyTodo.innerHTML = todos.map((p) => `
        <tr>
          <td>${escaparHtml(p.nombre)}</td>
          <td>${escaparHtml(p.sku || '—')}</td>
          <td>${p.stock}</td>
          <td>
            <button class="btn btn--secundario" style="padding:4px 10px; font-size:.75rem;"
                    onclick="ajustarStock(${p.idProducto})">Ajustar</button>
          </td>
        </tr>`).join('');
    }
  } catch (error) {
    if (tbodyBajo) tablaVacia(tbodyBajo, 5, error.message);
  }
}

async function ajustarStock(idProducto) {
  const entrada = prompt('Nuevo stock real del producto:');
  if (entrada === null) return;

  const cantidad = Number(entrada);
  if (!Number.isFinite(cantidad) || cantidad < 0) {
    alert('Ingresa un número válido.');
    return;
  }

  try {
    await Api.registrarMovimiento(idProducto, {
      tipo: 'ajuste',
      cantidad: Math.trunc(cantidad),
      motivo: 'Ajuste manual desde el panel'
    });
    await cargarInventario();
  } catch (error) {
    alert(error.message);
  }
}

/* ------------------------------- Reportes ------------------------------ */

async function cargarReportes() {
  try {
    const [resumen, vendidos] = await Promise.all([
      Api.resumenReporte(),
      Api.productosMasVendidos()
    ]);

    const tablaResumen = document.getElementById('tablaResumen');
    if (tablaResumen) {
      tablaResumen.innerHTML = [
        ['Pedidos del período', resumen.cantidadPedidos ?? 0],
        ['Ingresos del período', textoImporte(resumen.ingresosPeriodo)],
        ['Ingresos históricos', textoImporte(resumen.ingresosHistoricos)],
        ['Productos activos', resumen.productosActivos ?? 0],
        ['Productos con stock bajo', resumen.productosStockBajo ?? 0],
        ['Usuarios activos', resumen.usuariosActivos ?? 0]
      ].map(([k, v]) => `<tr><td>${k}</td><td><strong>${v}</strong></td></tr>`).join('');
    }

    const tablaVendidos = document.getElementById('tablaMasVendidos');
    if (tablaVendidos) {
      tablaVendidos.innerHTML = vendidos.length
        ? vendidos.map((p, i) => `<tr>
            <td>${i + 1}</td>
            <td>${escaparHtml(p.nombre)}</td>
            <td>${p.unidades}</td>
            <td>${textoImporte(p.ingresos)}</td>
          </tr>`).join('')
        : '<tr><td colspan="4" style="text-align:center; color:var(--texto-tenue);">Aún no hay ventas registradas.</td></tr>';
    }
  } catch (error) {
    console.warn('Reportes:', error.message);
  }
}

function exportarVentas(formato) {
  const url = Api.urlExportarVentas(undefined, undefined, formato);
  Api.descargar(url, formato === 'xml' ? 'ventas.xml' : 'ventas.csv')
    .catch((error) => alert(error.message));
}

/* ------------------------------- Soporte ------------------------------- */

async function cargarSoporte() {
  try {
    const solicitudes = await Api.solicitudes({ tamanio: 50 });
    const tbody = document.getElementById('tablaSolicitudes');
    if (tbody) {
      tbody.innerHTML = solicitudes.contenido.length
        ? solicitudes.contenido.map((s) => `<tr>
            <td>#${s.idSolicitud}</td>
            <td>${escaparHtml(s.servicio || '—')}</td>
            <td>${escaparHtml(s.nombre)}</td>
            <td>${s.tipo === 'cita' ? 'Cita' : 'Cotización'}</td>
            <td><span class="badge-rol">${estadoLegible(s.estado)}</span></td>
            <td>${escaparHtml(s.tecnicoAsignado || 'Sin asignar')}</td>
          </tr>`).join('')
        : '<tr><td colspan="6" style="text-align:center; color:var(--texto-tenue);">No hay solicitudes.</td></tr>';
    }
  } catch (error) {
    console.warn('Solicitudes:', error.message);
  }

  try {
    const contactos = await Api.contactos({ tamanio: 30 });
    const tbody = document.getElementById('tablaContactos');
    if (tbody) {
      tbody.innerHTML = contactos.contenido.length
        ? contactos.contenido.map((c) => `<tr>
            <td>#${c.idContacto}</td>
            <td>${escaparHtml(c.nombre)}</td>
            <td>${escaparHtml(c.correo)}</td>
            <td>${escaparHtml(c.asunto || '—')}</td>
            <td>${escaparHtml(c.tipo || 'mensaje')}</td>
            <td>${fechaCorta(c.creadoEn)}</td>
          </tr>`).join('')
        : '<tr><td colspan="6" style="text-align:center; color:var(--texto-tenue);">No hay mensajes.</td></tr>';
    }
  } catch (error) {
    console.warn('Contactos:', error.message);
  }
}

/* --------------------------------- Chat -------------------------------- */

async function cargarListaChats() {
  const tbody = document.getElementById('tablaChats');
  if (!tbody) return;

  try {
    const clientes = await Api.clientesChat();
    if (!clientes.length) {
      tbody.innerHTML = '<tr><td colspan="3" style="color:var(--texto-tenue);">Todavía no hay clientes registrados.</td></tr>';
      return;
    }
    tbody.innerHTML = clientes.map((c) => `
      <tr>
        <td>${escaparHtml(c.nombre)}</td>
        <td>${escaparHtml(c.correo)}</td>
        <td><a href="#" data-cliente="${c.idCliente}" data-nombre="${escaparHtml(c.nombre)}">Abrir</a></td>
      </tr>`).join('');

    tbody.querySelectorAll('[data-cliente]').forEach((enlace) => {
      enlace.addEventListener('click', (e) => {
        e.preventDefault();
        abrirConversacionCliente(enlace.dataset.cliente, enlace.dataset.nombre);
      });
    });
  } catch (error) {
    tbody.innerHTML = `<tr><td colspan="3" style="color:var(--texto-tenue);">${escaparHtml(error.message)}</td></tr>`;
  }
}

/** Prepara el panel de chat con el hilo del cliente elegido. */
function abrirConversacionCliente(idCliente, nombre) {
  const panel = document.getElementById('panelConversacion');
  const contenedor = document.getElementById('chatMensajes');
  if (!panel || !contenedor) return;

  panel.style.display = '';
  document.getElementById('chatConNombre').textContent = nombre || 'Conversación';
  contenedor.dataset.cliente = idCliente;
  contenedor.innerHTML = '';
  panel.scrollIntoView({ behavior: 'smooth', block: 'start' });
  inicializarChat();
}

/* ------------------------------- Favoritos ----------------------------- */

async function cargarFavoritos() {
  const contenedor = document.getElementById('listaFavoritos');
  if (!contenedor) return;

  try {
    const favoritos = await Api.favoritos();
    if (!favoritos.length) {
      contenedor.innerHTML = `<p class="cargando" style="color:var(--texto-tenue);">
        Todavía no tienes favoritos.
        <a href="../../pages/productos.html" style="color:var(--cian);">Explora el catálogo</a>
      </p>`;
      return;
    }

    contenedor.innerHTML = favoritos.map((p) => `
      <article class="tarjeta-producto">
        <div class="tarjeta-producto__imagen">
          <img src="../../${escaparHtml(p.imagen)}" alt="${escaparHtml(p.nombre)}">
        </div>
        <div class="tarjeta-producto__info">
          <h3>${escaparHtml(p.nombre)}</h3>
          <div class="tarjeta-producto__footer">
            <span class="precio">${textoImporte(p.precioFinal)}</span>
            <button class="btn-agregar" onclick="quitarFavorito(${p.idProducto})"
                    title="Quitar de favoritos"><i class="fa-solid fa-heart-crack"></i> Quitar</button>
          </div>
        </div>
      </article>`).join('');
  } catch (error) {
    contenedor.innerHTML = `<p class="cargando">${escaparHtml(error.message)}</p>`;
  }
}

async function quitarFavorito(idProducto) {
  try {
    await Api.alternarFavorito(idProducto);
    await cargarFavoritos();
  } catch (error) {
    alert(error.message);
  }
}

/* -------------------------------- Perfil ------------------------------- */

function cargarPerfil() {
  const form = document.getElementById('formPerfil');
  if (!form) return;

  const usuario = Api.getUsuario() || {};
  form.nombre.value = usuario.nombre || '';
  form.correo.value = usuario.correo || '';
  form.telefono.value = usuario.telefono || '';

  const respuesta = document.getElementById('respuestaPerfil');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    respuesta.className = 'form-respuesta';
    respuesta.textContent = '';

    try {
      const actualizado = await Api.put('/auth/me', {
        nombre: form.nombre.value.trim(),
        telefono: form.telefono.value.trim(),
        documento: usuario.documento || null,
        passwordActual: form.passwordActual.value || null,
        passwordNueva: form.passwordNueva.value || null
      });

      localStorage.setItem('tecnicsecure_usuario', JSON.stringify(actualizado));
      respuesta.textContent = 'Perfil actualizado correctamente.';
      respuesta.className = 'form-respuesta ok';
      form.passwordActual.value = '';
      form.passwordNueva.value = '';
      document.querySelectorAll('[data-nombre-usuario]').forEach((el) => {
        el.textContent = actualizado.nombre || '';
      });
    } catch (error) {
      respuesta.textContent = error.message;
      respuesta.className = 'form-respuesta error';
    }
  });
}

/* --------------------------- Mis pedidos (cliente) --------------------- */

async function cargarMisPedidos() {
  const tbody = document.getElementById('tablaMisPedidos');
  if (!tbody) return;

  try {
    const datos = await Api.misPedidos();
    if (!datos.contenido.length) {
      tablaVacia(tbody, 5, 'Aún no tienes pedidos.');
      return;
    }

    tbody.innerHTML = datos.contenido.map((p) => `
      <tr>
        <td>#${p.idPedido}</td>
        <td>${fechaCorta(p.creadoEn)}</td>
        <td>${textoImporte(p.total)}</td>
        <td><span class="badge-rol">${estadoLegible(p.estado)}</span></td>
        <td>${(p.detalles || []).length} producto(s)</td>
      </tr>`).join('');
  } catch (error) {
    tablaVacia(tbody, 5, error.message);
  }
}

/* ------------------------------ Auditoría ------------------------------ */

async function cargarAuditoria() {
  const tbody = document.getElementById('tablaAuditoria');
  if (!tbody) return;
  try {
    const datos = await Api.auditoria({ tamanio: 50 });
    const lista = datos.contenido || [];
    if (!lista.length) {
      tablaVacia(tbody, 4, 'Todavía no hay eventos registrados.');
      return;
    }
    tbody.innerHTML = lista.map((l) => `
      <tr>
        <td>${l.creadoEn ? new Date(l.creadoEn).toLocaleString('es-CO') : '—'}</td>
        <td>${escaparHtml(l.nombreUsuario || 'Sistema')}</td>
        <td><span class="badge-rol">${escaparHtml(l.accion)}</span></td>
        <td>${escaparHtml(l.detalle || '—')}</td>
      </tr>`).join('');
  } catch (error) {
    tablaVacia(tbody, 4, error.message);
  }
}

/* ----------------------------- Facturación ----------------------------- */

async function cargarFacturacion() {
  const tbody = document.getElementById('tablaFacturacion');
  if (!tbody) return;
  try {
    const datos = await Api.pedidos({ tamanio: 50 });
    const lista = datos.contenido || [];
    if (!lista.length) {
      tablaVacia(tbody, 6, 'No hay comprobantes generados.');
      return;
    }
    tbody.innerHTML = lista.map((p) => `
      <tr>
        <td><strong>FAC-${String(p.idPedido).padStart(5, '0')}</strong></td>
        <td>${escaparHtml(p.clienteNombre || '—')}</td>
        <td>${fechaCorta(p.creadoEn)}</td>
        <td><span class="badge-rol">${estadoLegible(p.estado)}</span></td>
        <td>${textoImporte(p.total)}</td>
        <td>
          <button type="button" class="panel-accion-btn" title="Imprimir comprobante" onclick="window.print()">
            <i class="fa-solid fa-print"></i>
          </button>
        </td>
      </tr>`).join('');
  } catch (error) {
    tablaVacia(tbody, 6, error.message);
  }
}

/* ------------------------------ Respaldo ------------------------------- */

function configurarRespaldo() {
  const btnVentas = document.getElementById('btnRespaldoVentas');
  const btnInv = document.getElementById('btnRespaldoInventario');
  const resp = document.getElementById('respuestaRespaldo');

  if (btnVentas) {
    btnVentas.addEventListener('click', async () => {
      try {
        await Api.descargar(Api.urlExportarVentas(), 'respaldo-ventas.csv');
        if (resp) { resp.textContent = 'Respaldo de ventas descargado.'; resp.className = 'form-respuesta ok'; }
      } catch (e) {
        if (resp) { resp.textContent = e.message; resp.className = 'form-respuesta error'; }
      }
    });
  }
  if (btnInv) {
    btnInv.addEventListener('click', async () => {
      try {
        await Api.descargar(Api.urlExportarInventario(), 'respaldo-inventario.csv');
        if (resp) { resp.textContent = 'Respaldo de inventario descargado.'; resp.className = 'form-respuesta ok'; }
      } catch (e) {
        if (resp) { resp.textContent = e.message; resp.className = 'form-respuesta error'; }
      }
    });
  }
}

/* -------------------------------- Arranque ----------------------------- */

document.addEventListener('DOMContentLoaded', () => {
  const pagina = window.location.pathname.split('/').pop() || 'index.html';
  const rol = document.body.dataset.rol;

  if (pagina === 'index.html') {
    if (rol === 'administrador') cargarDashboardAdmin();
    if (rol === 'empleado') cargarDashboardEmpleado();
    if (rol === 'cliente') cargarDashboardCliente();
  }
  if (pagina === 'usuarios.html' || pagina === 'clientes.html' || pagina === 'empleados.html') {
    inicializarUsuarios();
  }
  if (pagina === 'productos.html') inicializarProductos();
  if (pagina === 'pedidos.html') {
    if (rol === 'cliente') cargarMisPedidos();
    else cargarPedidos();
  }
  if (pagina === 'inventario.html') cargarInventario();
  if (pagina === 'reportes.html') cargarReportes();
  if (pagina === 'soporte.html') cargarSoporte();
  if (pagina === 'chat.html' && rol !== 'cliente') cargarListaChats();
  if (pagina === 'favoritos.html') cargarFavoritos();
  if (pagina === 'perfil.html') cargarPerfil();
  if (pagina === 'auditoria.html') cargarAuditoria();
  if (pagina === 'facturacion.html') cargarFacturacion();
  if (pagina === 'respaldo.html') configurarRespaldo();
});
