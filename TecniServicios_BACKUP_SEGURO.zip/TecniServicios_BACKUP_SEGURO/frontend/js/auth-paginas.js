/**
 * auth-paginas.js — Lógica de las pantallas de acceso
 * -----------------------------------------------------------------
 * · login.html       → POST /api/auth/login
 * · registro.html    → POST /api/auth/registro
 * · recuperar.html   → POST /api/auth/recuperar
 * · restablecer.html → POST /api/auth/restablecer
 * Mantiene las mismas validaciones y mensajes del sistema original.
 */

const MENSAJES_REDIRECCION = {
  administrador: 'panel/administrador/index.html',
  empleado: 'panel/empleado/index.html',
  cliente: 'panel/cliente/index.html'
};

function mostrarAlerta(contenedor, mensaje, tipo = 'error') {
  if (!contenedor) return;
  contenedor.textContent = mensaje;
  contenedor.className = `auth-alerta auth-alerta--${tipo === 'ok' ? 'ok' : tipo === 'info' ? 'info' : 'error'}`;
  contenedor.style.display = 'block';
}

function parametroUrl(nombre) {
  return new URLSearchParams(window.location.search).get(nombre) || '';
}

/* ------------------------------ Login ------------------------------ */

async function cargarCaptcha() {
  const contenedor = document.getElementById('preguntaCaptcha');
  if (!contenedor) return;
  try {
    const datos = await Api.get('/auth/captcha');
    contenedor.textContent = datos.pregunta;
  } catch {
    contenedor.textContent = '¿cuánto es 3 + 4?';
  }
}

function inicializarLogin() {
  const form = document.getElementById('formLogin');
  if (!form) return;

  // Si ya hay sesión, se entra directo al panel correspondiente.
  const usuario = Api.getUsuario();
  if (Api.estaAutenticado() && usuario) {
    window.location.href = MENSAJES_REDIRECCION[usuario.rol] || 'index.html';
    return;
  }

  cargarCaptcha();

  const alerta = document.getElementById('alertaLogin') || form.parentElement.querySelector('.auth-alerta');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const boton = form.querySelector('button[type="submit"]');
    const textoOriginal = boton.innerHTML;
    boton.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Entrando...';
    boton.disabled = true;

    try {
      const datos = await Api.post('/auth/login', {
        correo: form.correo.value.trim(),
        password: form.password.value
      });

      Api.guardarSesion(datos);

      const destino = parametroUrl('redir')
        || MENSAJES_REDIRECCION[datos.usuario.rol]
        || 'index.html';
      window.location.href = destino;
    } catch (error) {
      mostrarAlerta(alerta, error.message);
      cargarCaptcha();
      boton.innerHTML = textoOriginal;
      boton.disabled = false;
    }
  });
}

/* ----------------------------- Registro ---------------------------- */

function inicializarRegistro() {
  const form = document.getElementById('formRegistro');
  if (!form) return;

  const alerta = form.parentElement.querySelector('.auth-alerta');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const password = form.password.value;
    const password2 = form.password2.value;

    if (password !== password2) {
      mostrarAlerta(alerta, 'Las contraseñas no coinciden.');
      return;
    }
    if (!/^(?=.*[A-Z])(?=.*\d).{8,}$/.test(password)) {
      mostrarAlerta(alerta, 'La contraseña debe tener mínimo 8 caracteres, una mayúscula y un número.');
      return;
    }
    if (form.terminos && !form.terminos.checked) {
      mostrarAlerta(alerta, 'Debes aceptar los términos y condiciones.');
      return;
    }

    const boton = form.querySelector('button[type="submit"]');
    const textoOriginal = boton.innerHTML;
    boton.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Creando cuenta...';
    boton.disabled = true;

    try {
      const respuesta = await Api.post('/auth/registro', {
        nombre: form.nombre.value.trim(),
        documento: form.documento.value.trim(),
        correo: form.correo.value.trim(),
        telefono: form.telefono.value.trim(),
        password
      });

      mostrarAlerta(alerta, respuesta.mensaje, 'ok');
      form.reset();
      setTimeout(() => { window.location.href = 'login.html?exito=' + encodeURIComponent(respuesta.mensaje); }, 1200);
    } catch (error) {
      mostrarAlerta(alerta, error.message);
      boton.innerHTML = textoOriginal;
      boton.disabled = false;
    }
  });
}

/* ---------------------------- Recuperar ---------------------------- */

function inicializarRecuperar() {
  const form = document.getElementById('formRecuperar') || document.querySelector('.auth-form');
  if (!form) return;

  const alerta = form.parentElement.querySelector('.auth-alerta');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const correo = (form.correo || form.querySelector('#correo')).value.trim();
    const boton = form.querySelector('button[type="submit"]');
    const textoOriginal = boton.innerHTML;
    boton.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Enviando...';
    boton.disabled = true;

    try {
      const respuesta = await Api.post('/auth/recuperar', { correo });
      mostrarAlerta(alerta, respuesta.mensaje, 'ok');

      if (respuesta.tokenDesarrollo) {
        const caja = document.getElementById('enlaceRecuperacion');
        const enlace = document.getElementById('enlaceRestablecer');
        if (caja && enlace) {
          enlace.href = `restablecer.html?token=${encodeURIComponent(respuesta.tokenDesarrollo)}`;
          caja.style.display = 'block';
        }
      }
    } catch (error) {
      mostrarAlerta(alerta, error.message);
    } finally {
      boton.innerHTML = textoOriginal;
      boton.disabled = false;
    }
  });
}

/* --------------------------- Restablecer --------------------------- */

function inicializarRestablecer() {
  const form = document.getElementById('formRestablecer');
  if (!form) return;

  const alerta = form.parentElement.querySelector('.auth-alerta');
  const token = parametroUrl('token');
  if (!token) {
    mostrarAlerta(alerta, 'El enlace no es válido. Solicita uno nuevo.');
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (form.password.value !== form.password2.value) {
      mostrarAlerta(alerta, 'Las contraseñas no coinciden.');
      return;
    }

    const boton = form.querySelector('button[type="submit"]');
    const textoOriginal = boton.innerHTML;
    boton.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Guardando...';
    boton.disabled = true;

    try {
      await Api.post('/auth/restablecer', { token, password: form.password.value });
      mostrarAlerta(alerta, 'Contraseña actualizada. Ya puedes iniciar sesión.', 'ok');
      setTimeout(() => { window.location.href = 'login.html'; }, 1500);
    } catch (error) {
      mostrarAlerta(alerta, error.message);
      boton.innerHTML = textoOriginal;
      boton.disabled = false;
    }
  });
}

/* ------------- Encabezado dinámico (usuario conectado) ------------- */

function pintarEstadoSesion() {
  const enlaceCuenta = document.getElementById('btnCuenta');
  if (!enlaceCuenta) return;

  const usuario = Api.getUsuario();
  if (Api.estaAutenticado() && usuario) {
    const primerNombre = (usuario.nombre || '').split(' ')[0];
    enlaceCuenta.innerHTML = `<i class="fa-solid fa-user"></i> ${escaparHtml(primerNombre)}`;
    enlaceCuenta.href = MENSAJES_REDIRECCION[usuario.rol] || 'index.html';
    enlaceCuenta.title = 'Ir a mi panel';
  }
}

document.addEventListener('DOMContentLoaded', () => {
  inicializarLogin();
  inicializarRegistro();
  inicializarRecuperar();
  inicializarRestablecer();
  pintarEstadoSesion();
});
