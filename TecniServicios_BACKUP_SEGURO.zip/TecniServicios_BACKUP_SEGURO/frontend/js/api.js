/**
 * api.js — Cliente de la API REST de TECNISECURE
 * -----------------------------------------------------------------
 * Centraliza TODAS las llamadas HTTP al backend Spring Boot:
 *   · Guarda el token JWT en localStorage.
 *   · Añade la cabecera Authorization automáticamente.
 *   · Renueva el token cuando expira (refresh token).
 *   · Traduce los errores de la API a mensajes en español.
 * Inclúyelo ANTES que los demás scripts.
 */

const API_CONFIG = {
  // Mismo origen que sirve el frontend (Spring Boot en :8080)
  base: window.API_BASE || `${window.location.origin}/api`,
  tokenKey: 'tecnicsecure_token',
  refreshKey: 'tecnicsecure_refresh',
  usuarioKey: 'tecnicsecure_usuario'
};

const Api = {
  /* ---------------------------- Sesión ---------------------------- */

  getToken() {
    return localStorage.getItem(API_CONFIG.tokenKey);
  },

  getRefreshToken() {
    return localStorage.getItem(API_CONFIG.refreshKey);
  },

  getUsuario() {
    const datos = localStorage.getItem(API_CONFIG.usuarioKey);
    return datos ? JSON.parse(datos) : null;
  },

  estaAutenticado() {
    return Boolean(this.getToken());
  },

  guardarSesion(respuesta) {
    localStorage.setItem(API_CONFIG.tokenKey, respuesta.accessToken);
    if (respuesta.refreshToken) {
      localStorage.setItem(API_CONFIG.refreshKey, respuesta.refreshToken);
    }
    if (respuesta.usuario) {
      localStorage.setItem(API_CONFIG.usuarioKey, JSON.stringify(respuesta.usuario));
      document.dispatchEvent(new CustomEvent('sesion:cambiada', { detail: respuesta.usuario }));
    }
  },

  cerrarSesion() {
    localStorage.removeItem(API_CONFIG.tokenKey);
    localStorage.removeItem(API_CONFIG.refreshKey);
    localStorage.removeItem(API_CONFIG.usuarioKey);
    document.dispatchEvent(new CustomEvent('sesion:cerrada'));
  },

  /* --------------------------- Peticiones -------------------------- */

  async _peticion(ruta, opciones = {}, reintentar = true) {
    const cabeceras = { 'Accept': 'application/json', ...(opciones.headers || {}) };

    if (opciones.body !== undefined && !(opciones.body instanceof FormData)) {
      cabeceras['Content-Type'] = 'application/json';
      if (typeof opciones.body !== 'string') {
        opciones.body = JSON.stringify(opciones.body);
      }
    }

    const token = this.getToken();
    if (token) {
      cabeceras['Authorization'] = `Bearer ${token}`;
    }

    let respuesta;
    try {
      respuesta = await fetch(`${API_CONFIG.base}${ruta}`, { ...opciones, headers: cabeceras });
    } catch (errorRed) {
      throw new Error('No se pudo conectar con el servidor. Verifica que el backend esté encendido.');
    }

    // Token expirado → intentar renovarlo una sola vez
    if (respuesta.status === 401 && reintentar && this.getRefreshToken()) {
      if (await this._renovarToken()) {
        return this._peticion(ruta, opciones, false);
      }
      this.cerrarSesion();
    }

    if (respuesta.status === 204) {
      return null;
    }

    const tipo = respuesta.headers.get('content-type') || '';
    const cuerpo = tipo.includes('application/json') ? await respuesta.json() : await respuesta.text();

    if (!respuesta.ok) {
      const mensaje = (cuerpo && (cuerpo.mensaje || cuerpo.message)) || `Error ${respuesta.status}`;
      const error = new Error(mensaje);
      error.status = respuesta.status;
      error.campos = cuerpo && cuerpo.campos;
      throw error;
    }

    return cuerpo;
  },

  async _renovarToken() {
    try {
      const respuesta = await fetch(`${API_CONFIG.base}/auth/refresh`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ refreshToken: this.getRefreshToken() })
      });
      if (!respuesta.ok) return false;
      this.guardarSesion(await respuesta.json());
      return true;
    } catch {
      return false;
    }
  },

  get: (ruta) => Api._peticion(ruta, { method: 'GET' }),
  post: (ruta, body) => Api._peticion(ruta, { method: 'POST', body }),
  put: (ruta, body) => Api._peticion(ruta, { method: 'PUT', body }),
  patch: (ruta, body) => Api._peticion(ruta, { method: 'PATCH', body }),
  delete: (ruta) => Api._peticion(ruta, { method: 'DELETE' }),

  /* --------------------------- Catálogo ---------------------------- */

  productos(params = {}) {
    const query = new URLSearchParams(
      Object.entries(params).filter(([, v]) => v !== undefined && v !== null && v !== '')
    ).toString();
    return this.get(`/productos${query ? `?${query}` : ''}`);
  },

  destacados: () => Api.get('/productos/destacados'),
  producto: (id) => Api.get(`/productos/${id}`),
  crearProducto: (datos) => Api.post('/productos', datos),
  actualizarProducto: (id, datos) => Api.put(`/productos/${id}`, datos),
  eliminarProducto: (id) => Api.delete(`/productos/${id}`),
  categorias: () => Api.get('/categorias'),
  marcas: () => Api.get('/marcas'),
  servicios: () => Api.get('/servicios'),

  /* --------------------- Usuarios y Auditoría ---------------------- */

  usuarios(params = {}) {
    const query = new URLSearchParams(
      Object.entries(params).filter(([, v]) => v !== undefined && v !== null && v !== '')
    ).toString();
    return Api.get(`/usuarios${query ? `?${query}` : ''}`);
  },
  usuario: (id) => Api.get(`/usuarios/${id}`),
  crearUsuario: (datos) => Api.post('/usuarios', datos),
  actualizarUsuario: (id, datos) => Api.put(`/usuarios/${id}`, datos),
  eliminarUsuario: (id) => Api.delete(`/usuarios/${id}`),
  auditoria: (params = {}) => {
    const query = new URLSearchParams(params).toString();
    return Api.get(`/auditoria${query ? `?${query}` : ''}`);
  },

  /* ----------------------------- Pedidos --------------------------- */

  registrarPedido: (datos) => Api.post('/pedidos', datos),
  misPedidos: () => Api.get('/pedidos/mis-pedidos'),
  pedidos: (params = {}) => {
    const query = new URLSearchParams(params).toString();
    return Api.get(`/pedidos${query ? `?${query}` : ''}`);
  },
  pedido: (id) => Api.get(`/pedidos/${id}`),
  cambiarEstadoPedido: (id, estado, observacion) =>
    Api.patch(`/pedidos/${id}/estado`, { estado, observacion }),

  /* --------------------------- Inventario -------------------------- */

  stockBajo: () => Api.get('/inventario/stock-bajo'),
  inventario: () => Api.get('/inventario'),
  kardex: (idProducto) => Api.get(`/inventario/productos/${idProducto}/kardex`),
  movimientos: () => Api.get('/inventario/movimientos'),
  registrarMovimiento: (idProducto, datos) =>
    Api.post(`/inventario/productos/${idProducto}/movimientos`, datos),

  /* ----------------------------- Soporte --------------------------- */

  enviarContacto: (datos) => Api.post('/contactos', datos),
  contactos: (params = {}) => {
    const query = new URLSearchParams(params).toString();
    return Api.get(`/contactos${query ? `?${query}` : ''}`);
  },
  solicitarServicio: (datos) => Api.post('/solicitudes', datos),
  solicitudes: (params = {}) => {
    const query = new URLSearchParams(params).toString();
    return Api.get(`/solicitudes${query ? `?${query}` : ''}`);
  },
  gestionarSolicitud: (id, datos) => Api.patch(`/solicitudes/${id}`, datos),

  miConversacion: () => Api.get('/chat/mi-conversacion'),
  enviarMensajePropio: (mensaje) => Api.post('/chat/mi-conversacion', { mensaje }),
  clientesChat: () => Api.get('/chat/clientes'),
  conversacion: (idCliente) => Api.get(`/chat/${idCliente}`),
  responderChat: (idCliente, mensaje) => Api.post(`/chat/${idCliente}`, { mensaje }),

  notificaciones: () => Api.get('/notificaciones'),
  notificacionesSinLeer: () => Api.get('/notificaciones/sin-leer'),
  marcarNotificacionesLeidas: () => Api.patch('/notificaciones/leidas', {}),

  /* ----------------------------- Reportes -------------------------- */

  resumenReporte: (desde, hasta) =>
    Api.get(`/reportes/resumen${Api._rango(desde, hasta)}`),
  productosMasVendidos: (desde, hasta) =>
    Api.get(`/reportes/productos-mas-vendidos${Api._rango(desde, hasta)}`),
  urlExportarVentas: (desde, hasta, formato = 'csv') =>
    `${API_CONFIG.base}/reportes/ventas/export${Api._rango(desde, hasta)}&formato=${formato}`,
  urlExportarInventario: (desde, hasta) =>
    `${API_CONFIG.base}/reportes/inventario/export${Api._rango(desde, hasta)}`,

  _rango(desde, hasta) {
    const parametros = new URLSearchParams();
    if (desde) parametros.set('desde', desde);
    if (hasta) parametros.set('hasta', hasta);
    const consulta = parametros.toString();
    return consulta ? `?${consulta}` : '';
  },

  /* ----------------------------- Cliente --------------------------- */

  favoritos: () => Api.get('/cliente/favoritos'),
  alternarFavorito: (idProducto) => Api.post(`/cliente/favoritos/${idProducto}`, {}),
  resenas: (idProducto) => Api.get(`/cliente/productos/${idProducto}/resenas`),
  resenar: (idProducto, datos) => Api.post(`/cliente/productos/${idProducto}/resenas`, datos),

  /* ---------------------------- Utilidades ------------------------- */

  /** Descarga un archivo protegido enviando el token JWT. */
  async descargar(url, nombreArchivo) {
    const respuesta = await fetch(url, {
      headers: { Authorization: `Bearer ${this.getToken()}` }
    });
    if (!respuesta.ok) {
      throw new Error('No se pudo generar el archivo');
    }
    const blob = await respuesta.blob();
    const enlace = document.createElement('a');
    enlace.href = URL.createObjectURL(blob);
    enlace.download = nombreArchivo;
    document.body.appendChild(enlace);
    enlace.click();
    enlace.remove();
    URL.revokeObjectURL(enlace.href);
  }
};

/** Formatea un valor como pesos colombianos: 249900 → $249.900 */
function formatearPesos(valor) {
  const numero = Number(valor || 0);
  return '$' + numero.toLocaleString('es-CO', { maximumFractionDigits: 0 });
}

/** Escapa texto antes de insertarlo con innerHTML. */
function escaparHtml(texto) {
  return String(texto ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

window.Api = Api;
