/**
 * panel.js — Comportamiento común del panel (todos los roles)
 * -----------------------------------------------------------------
 * · Menú lateral en móvil.
 * · Campana de notificaciones (API REST).
 * · Chat con actualización en tiempo real:
 *      1) WebSocket STOMP si está disponible  → instantáneo.
 *      2) Respaldo por sondeo cada 4 s        → siempre funciona.
 */

document.addEventListener('DOMContentLoaded', () => {
  inicializarMenuLateral();
  inicializarNotificaciones();
  inicializarChat();
  pintarUsuarioPanel();
  protegerPanel();
});

/** Si no hay sesión, vuelve al login. */
function protegerPanel() {
  if (!Api.estaAutenticado()) {
    window.location.href = '../../login.html?redir=' + encodeURIComponent(window.location.pathname);
  }
}

/* --------------------------- Menú lateral -------------------------- */

function inicializarMenuLateral() {
  const toggle = document.getElementById('panelToggle');
  const sidebar = document.getElementById('panelSidebar');
  const overlay = document.getElementById('panelOverlay');

  const abrir = () => {
    sidebar?.classList.add('activo');
    overlay?.classList.add('activo');
  };
  const cerrar = () => {
    sidebar?.classList.remove('activo');
    overlay?.classList.remove('activo');
  };

  if (toggle) toggle.addEventListener('click', abrir);
  if (overlay) overlay.addEventListener('click', cerrar);
}

/* ------------------------ Datos del usuario ------------------------ */

function pintarUsuarioPanel() {
  const usuario = Api.getUsuario();
  if (!usuario) return;

  document.querySelectorAll('[data-nombre-usuario]').forEach((el) => { el.textContent = usuario.nombre || ''; });
  document.querySelectorAll('[data-correo-usuario]').forEach((el) => { el.textContent = usuario.correo || ''; });
  document.querySelectorAll('[data-rol-usuario]').forEach((el) => { el.textContent = usuario.rol || ''; });
  document.querySelectorAll('[data-avatar-usuario]').forEach((el) => {
    if (usuario.avatar) {
      el.innerHTML = `<img src="${escaparHtml(usuario.avatar)}" alt="Foto de perfil">`;
    } else {
      el.textContent = (usuario.nombre || '?').charAt(0).toUpperCase();
    }
  });
}

/* -------------------------- Notificaciones ------------------------- */

async function inicializarNotificaciones() {
  const boton = document.getElementById('botonNotificaciones');
  const dropdown = document.getElementById('dropdownNotificaciones');
  const contador = document.getElementById('notificacionesContador');
  const lista = document.getElementById('listaNotificaciones');

  if (!Api.estaAutenticado() || !boton) return;

  async function refrescar() {
    try {
      const [sinLeer, notificaciones] = await Promise.all([
        Api.notificacionesSinLeer(),
        Api.notificaciones()
      ]);

      if (contador) {
        contador.textContent = sinLeer.total || 0;
        contador.style.display = sinLeer.total > 0 ? 'flex' : 'none';
      }

      if (lista) {
        lista.innerHTML = notificaciones.length
          ? notificaciones.map((n) => `
              <li class="${n.leida ? '' : 'no-leida'}">
                <strong>${escaparHtml(n.titulo)}</strong>
                <span>${escaparHtml(n.mensaje || '')}</span>
                <small>${new Date(n.creadoEn).toLocaleString('es-CO')}</small>
              </li>`).join('')
          : '<li class="vacio">No tienes notificaciones.</li>';
      }
    } catch {
      /* la campana es informativa: si falla no interrumpe el panel */
    }
  }

  boton.addEventListener('click', async (e) => {
    e.stopPropagation();
    dropdown?.classList.toggle('activo');
    if (dropdown?.classList.contains('activo')) await refrescar();
  });

  document.addEventListener('click', (e) => {
    if (dropdown && !dropdown.contains(e.target) && !boton.contains(e.target)) {
      dropdown.classList.remove('activo');
    }
  });

  const marcar = document.getElementById('marcarNotificaciones');
  if (marcar) {
    marcar.addEventListener('click', async () => {
      await Api.marcarNotificacionesLeidas();
      refrescar();
    });
  }

  refrescar();
  setInterval(refrescar, 60000);

  // Tiempo real: el backend publica en /topic/notificaciones/{idUsuario}.
  const idUsuario = Api.getUsuario()?.idUsuario;
  if (idUsuario) {
    let pendiente = null;
    Ws.suscribir(`/topic/notificaciones/${idUsuario}`, () => {
      clearTimeout(pendiente);
      pendiente = setTimeout(refrescar, 400);
    });
  }
}

/* ------------------------------- Chat ------------------------------ */

function inicializarChat() {
  const form = document.getElementById('formChat');
  const contenedor = document.getElementById('chatMensajes');
  if (!contenedor) return;

  // Evita duplicar temporizadores y suscripciones al cambiar de cliente.
  if (contenedor.dataset.iniciado === '1') return;
  contenedor.dataset.iniciado = '1';

  const idCliente = contenedor.dataset.cliente;
  const esPanelCliente = contenedor.dataset.rol === 'cliente';

  const pintar = (mensajes) => {
    contenedor.innerHTML = mensajes.map((m) => `
      <div class="chat-burbuja chat-burbuja--${m.remitente === 'cliente' ? 'cliente' : 'asesor'}">
        ${escaparHtml(m.mensaje)}
        <small>${new Date(m.creadoEn).toLocaleString('es-CO',
          { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}</small>
      </div>`).join('');
    contenedor.scrollTop = contenedor.scrollHeight;
  };

  const cargar = async () => {
    try {
      const mensajes = esPanelCliente
        ? await Api.miConversacion()
        : await Api.conversacion(idCliente);
      pintar(mensajes || []);
    } catch {
      /* se conserva lo último mostrado */
    }
  };

  cargar();
  setInterval(cargar, 4000);

  // Tiempo real: el backend publica cada mensaje nuevo en /topic/chat/{idCliente}.
  const idHilo = esPanelCliente ? Api.getUsuario()?.idCliente : idCliente;
  if (idHilo) {
    Ws.suscribir(`/topic/chat/${idHilo}`, () => cargar());
  }

  if (form) {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const input = document.getElementById('mensajeChat');
      const texto = (input.value || '').trim();
      if (!texto) return;

      input.value = '';
      try {
        if (esPanelCliente) {
          await Api.enviarMensajePropio(texto);
        } else {
          await Api.responderChat(idCliente, texto);
        }
        await cargar();
      } catch (error) {
        input.value = texto;
        alert(error.message);
      }
    });
  }
}

/* ---------------------------- Cerrar sesión ------------------------ */

function cerrarSesionPanel() {
  Api.cerrarSesion();
  window.location.href = '../../login.html';
}
