# PROYECTO DE AULA: TECNISERVICIOS (TECNISECURE)
## Plataforma Integral de Gestión Comercial, Control de Inventario y Soporte en Seguridad Electrónica
### Programa de Ingeniería de Sistemas — 6to Semestre

---

## 📌 Guía y Estructura de Documentación Técnica

Esta carpeta contiene la documentación oficial del proyecto de aula **TecniServicios**, compilada bajo estrictas normas académicas e ingenieriles en formato **Word (.docx)** y formato **PDF estándar**.

---

### 📄 Documento Oficial Unificado en Word (.docx)

* **[Documento_Tecnico_TecniServicios.docx](Documento_Tecnico_TecniServicios.docx)** (56 KB)  
  *Documento completo y continuo en formato Microsoft Word (.docx), diagramado exclusivamente a blanco y negro, sin elementos decorativos, con enumeración correlativa (del 1 al 8) y basado total y únicamente en el código y arquitectura real de TecniServicios.*

---

### 📑 Estructura del Documento

1. **Preliminares:** Portada académica formal (Unicolombo), Introducción, Justificación (práctica, técnica y social) y Objetivos (general y específicos).
2. **Planteamiento del Problema:** Descripción de la necesidad en la vida real, formulación de ingeniería y Árbol de causas y efectos.
3. **Marco Teórico / Tecnológico:** Conceptos fundamentales (REST, JWT, ORM, MVC, WebSockets), Justificación del stack tecnológico (Java 21, Spring Boot 3.3, H2, Vanilla JS) y Metodología Scrum (roles, eventos y cronograma de 4 Sprints).
4. **Especificación de Requisitos:** Catálogo de 18 Requisitos Funcionales (RF), 8 Requisitos No Funcionales (RNF con métricas de seguridad y latencia), Historias de Usuario con formato Gherkin y Matriz de Casos de Uso por Rol.
5. **Diseño e Ingeniería del Sistema:** Diagrama de Componentes de 3 capas, Modelo Entidad-Relación (MER con 24 entidades), Diccionario de datos y Diagramas UML (Clases, Secuencia de Login JWT, Secuencia de Pedido/Stock y Despliegue de nodos).
6. **Resultados y Pruebas:** Evidencia de pruebas unitarias ejecutadas con JUnit 5 y Mockito (7 suites del backend probadas al 100%) y Matriz de Trazabilidad y Aceptación de Requisitos.
7. **Conclusiones y Trabajo Futuro:** Conclusiones técnicas de la solución desarrollada y líneas de trabajo futuro para la Fase 2 (pasarelas de pago, app móvil Flutter, tracking GPS).
8. **Bibliografía:** Fuentes y documentación técnica normalizadas en formato IEEE y APA (7ma edición).

---

### 🗂️ Anexos Técnicos

* **[anexos/schema.sql](anexos/schema.sql)** (10 KB): Script SQL DDL puro con la creación formal de tablas (`CREATE TABLE`), llaves primarias, llaves foráneas e índices (compatible con H2 y MySQL).
* **[anexos/Guia_Sustentacion_y_Demo.pdf](anexos/Guia_Sustentacion_y_Demo.pdf)** (126 KB): Guía ejecutiva de diapositivas y guión paso a paso para la demostración funcional en vivo.
